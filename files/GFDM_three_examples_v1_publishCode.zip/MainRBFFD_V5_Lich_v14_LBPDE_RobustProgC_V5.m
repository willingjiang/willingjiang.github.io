clear all,

addpath ./Estimate_Filter_P
addpath ./RBF_Matrix

%%% 1 = full ellipse, 2 = full torus, 3 = semi-torus
EXAMPLE = 3;
%%% 1 = known, 2 = 2nd SVD, 3 = GMLS
UNKNOWN = 1;
%% given manifold parameters and information
if EXAMPLE == 1 % full ellipse
    %%% manifold parameter
    d = 1;
    n = 2;
    N = 400;
    
    %%% polynomial regression
    %%% k-NN
    k0 = 21;
    %%% degree
    degr = 5;
    %%% 1=LB, 2=Boch, 3=Hodge, 4=Lich
    operator = 1;
    
    %%% extrinsic data
    am = 2;
    %%% 1 == well-sampled data
    %%% 2 == random data
    DATA_INDEX = 2;
    
    %%% generate data
    rng(5);
    [x,theta] = ellipse_generate(DATA_INDEX,am,N);
    %%% 1 = interior, 8 = boundary, if not sure, a classifier needed here
    indexIB = ones(N,1); % all interior
    %%% projection matrix P0
    if UNKNOWN == 1
        [P0,tvec2] = ellipse_P0Cheat_v2(theta,x,am);
    elseif UNKNOWN == 2
        kk = 21; % 16 for ellipse and 50 for torus
        indxB = 1:N;
        [P0,tvec2] = geod_mean_normal_svd_v4_pick_V3(x,kk,d,indxB);
    elseif UNKNOWN == 3        
        kk = 21; %%% k-NN        
        degr0 = 5; %%% degree        
        indxB = 1:N; %%% index for tangent space
        [P0,tvec2] = gmls_localPCA_v2(x,kk,d,n,degr0,indxB);
    end
    %%% analytic computation of solution and LB
    [Lgf_true,func] = ellipse_analytic_computation(theta,am);
    
elseif EXAMPLE == 2 % full torus
    %%% manifold parameter
    d = 2;
    n = 3;
    Ntheta = 32;
    Nphi = 32;
    N = Ntheta*Nphi; % total # of points on manifold
    
    %%% polynomial regression
    %%% k-NN
    k0 = 51;
    %%% degree 
    degr = 4;
    %%% 1=LB, 2=Boch, 3=Hodge, 4=Lich
    operator = 1;

    % extrinsic data
    am = 2;   % a > 1 radius of larger circle
    %%% 1 == well-sampled data
    %%% 2 == random data
    DATA_INDEX = 2;
    
    %%% generate data
    rng(5);
    [x,theta] = torus_generate(DATA_INDEX,am,Ntheta,Nphi);
    %%% 1 = interior, 8 = boundary, if not sure, a classifier needed here
    indexIB = ones(N,1); % all interior
    %%% projection matrix P0
    if UNKNOWN == 1
        [P0,tvec2] = torus_P0Cheat_v2(theta,x,am);
    elseif UNKNOWN == 2
        kk = 51; % 16 for ellipse and 50 for torus
        indxB = 1:N;
        [P0,tvec2] = geod_mean_normal_svd_v4_pick_V3(x,kk,d,indxB);
    elseif UNKNOWN == 3        
        kk = 51; %%% k-NN        
        degr0 = 5; %%% degree        
        indxB = 1:N; %%% index for tangent space
        [P0,tvec2] = gmls_localPCA_v2(x,kk,d,n,degr0,indxB);    
    end
    
    %%% analytic computation for torus
    cvar = 0;
    %%% analytical solution for verification
    %%% find solution u satisfying the bc beta1/a^1*up + u = 0;
    %%% parameters for arbitrary test solution
    sol.k = 2;
    sol.beta1 = 0;
    sol.alpha1 = 1;

    [Lgf_true,~,func] = torus_fcompute(theta(:,1),theta(:,2),am,sol,cvar);

elseif EXAMPLE == 3 % semi-torus
    %%% manifold parameter
    d = 2;
    n = 3;
    Ntheta = 32;
    Nphi = 32;
    N = Ntheta*Nphi; % total # of points on manifold
    
    %%% polynomial regression
    %%% k-NN
    k0 = 51;
    %%% degree 
    degr = 4;
    %%% 1=LB, 2=Boch, 3=Hodge, 4=Lich
    operator = 1;

    % extrinsic data
    am = 2;   % a > 1 radius of larger circle
    %%% 1 == well-sampled data
    %%% 2 == random data
    DATA_INDEX = 2;
    
    %%% generate data
    rng(5);
    minphi = 0;
    maxphi = pi;
    %%% 1 = interior, 8 = boundary, if not sure, a classifier needed here
    [x,theta,indexIB] = semitorus_generate(DATA_INDEX,am,Ntheta,Nphi,minphi,maxphi);
    
    %%% projection matrix P0
    if UNKNOWN == 1
        [P0,tvec2] = semitorus_P0Cheat(theta,x,am);
    elseif UNKNOWN == 2
        kk = 51; % 16 for ellipse and 50 for torus
        indxB = 1:N;
        [P0,tvec2] = geod_mean_normal_svd_v4_pick_V3(x,kk,d,indxB);
    elseif UNKNOWN == 3        
        kk = 51; %%% k-NN        
        degr0 = 5; %%% degree        
        indxB = 1:N; %%% index for tangent space
        [P0,tvec2] = gmls_localPCA_v2(x,kk,d,n,degr0,indxB);    
    end
    
    %%% analytic computation for torus
    cvar = 0;
    %%% analytical solution for verification
    %%% find solution u satisfying the bc beta1/a^1*up + u = 0;
    %%% parameters for arbitrary test solution
    sol.k = 2;
    sol.beta1 = 0;
    sol.alpha1 = 1;

    [Lgf_true,~,func] = semitorus_fcompute(theta(:,1),theta(:,2),am,sol,cvar);
       
end



%% PDE solver

if operator == 1
    if sum(indexIB==8) == 0 % no boundary case
        cm = 1;
    else % with boundary case
        cm = 0;
    end
    %%% solve (I-Delta)*u = f
    Rhs = cm*func - Lgf_true;
    
    %%% intrinsic polynomial regression, fix linear polynomial, normalization
    %%% of data, degree arbitrary, Laplace-Beltrami
    % [Matrix_Lap1_Local] = LichLocalCompute_v6p3_PolyRegr_Beltrami(x,k0,degr,P0,tvec2,operator);
    [Matrix_Lap1_Local] = LichLocalCompute_v6p3_PolyRegr_Beltrami_V2(x,k0,degr,P0,tvec2,operator,indexIB);
    %%% intrinsic polynomial regression, fix linear polynomial, normalization
    %%% of data, degree arbitrary, Non-SDD Laplace-Beltrami, Linear + Quadratic
    %%% Robust Programming + Addaptive Knn
    %%% Add constraint c/max|w| << 1
    % [Matrix_Lap3_Local,lin_data] = LichLocalCompute_v6p14_PolyRegr_RobustProg_V3_newCode(x,k0,degr,P0,tvec2,operator);
    % [Matrix_Lap3_Local,lin_data] = LichLocalCompute_v6p14_PolyRegr_RobustProg_V4_newCode(x,k0,degr,P0,tvec2,operator); % all interior
    [Matrix_Lap3_Local,lin_data] = LichLocalCompute_v6p14_PolyRegr_RobustProg_V5_newCode(x,k0,degr,P0,tvec2,operator,indexIB); % boundary possible

    if sum(indexIB==8) == 0 % no boundary case
        %%% Local-FD numerical Lich Laplacian
        LBf_col_num1 = Matrix_Lap1_Local*func;
        LBf_col_num3 = Matrix_Lap3_Local*func;

        sol1 = (cm*speye(N)-Matrix_Lap1_Local)\Rhs;
        sol3 = (cm*speye(N)-Matrix_Lap3_Local)\Rhs;

        LBf_invs1 = (cm*speye(N)-Matrix_Lap1_Local)\speye(N);
        LBf_invs3 = (cm*speye(N)-Matrix_Lap3_Local)\speye(N);

        %%% shown output
        disp('consistency');
        errP_local_Linf1 = max(abs(LBf_col_num1-Lgf_true));
        errP_local_Linf3 = max(abs(LBf_col_num3-Lgf_true));
        [errP_local_Linf1]
        [errP_local_Linf3]

        disp('stability');
        inf_norm1 = norm(LBf_invs1,Inf);
        inf_norm3 = norm(LBf_invs3,Inf);
        [inf_norm1]
        [inf_norm3]

        disp('convergence');
        err_sol_Linf1 = max(abs(sol1-func));
        err_sol_Linf3 = max(abs(sol3-func));
        [err_sol_Linf1]
        [err_sol_Linf3]

        figure,
        subplot(3,1,1);
        plot(lin_data.exitflag1,'go');hold on;plot(lin_data.exitflag2,'r.');
        ylabel('exitflag');
        subplot(3,1,2);
        plot(lin_data.stdminerr);
        ylabel('min C');
        subplot(3,1,3);
        plot(lin_data.iter_numb,'r');
        ylabel('iter num');

    else % with boundary case

        %%% Local-FD numerical Lich Laplacian
        LBf_col_num1 = Matrix_Lap1_Local(indexIB==1,:)*func;
        LBf_col_num3 = Matrix_Lap3_Local(indexIB==1,:)*func;

        sol1 = zeros(N,1);
        sol1(indexIB==8) = func(indexIB==8);
        sol1(indexIB==1) = (cm*speye(N-sum(indexIB==8))-Matrix_Lap1_Local(indexIB==1,indexIB==1)) \ (Rhs(indexIB==1)+Matrix_Lap1_Local(indexIB==1,indexIB==8)*func(indexIB==8));
        sol3 = zeros(N,1);
        sol3(indexIB==8) = func(indexIB==8);
        sol3(indexIB==1) = (cm*speye(N-sum(indexIB==8))-Matrix_Lap3_Local(indexIB==1,indexIB==1)) \ (Rhs(indexIB==1)+Matrix_Lap3_Local(indexIB==1,indexIB==8)*func(indexIB==8));

        LBf_invs1 = (cm*speye(N-sum(indexIB==8))-Matrix_Lap1_Local(indexIB==1,indexIB==1))\speye(N-sum(indexIB==8));
        LBf_invs3 = (cm*speye(N-sum(indexIB==8))-Matrix_Lap3_Local(indexIB==1,indexIB==1))\speye(N-sum(indexIB==8));

        %%% shown output
        disp('consistency');
        errP_local_Linf1 = max(abs(LBf_col_num1-Lgf_true(indexIB==1)));
        errP_local_Linf3 = max(abs(LBf_col_num3-Lgf_true(indexIB==1)));
        [errP_local_Linf1]
        [errP_local_Linf3]

        disp('stability');
        inf_norm1 = norm(LBf_invs1,Inf);
        inf_norm3 = norm(LBf_invs3,Inf);
        [inf_norm1]
        [inf_norm3]

        disp('convergence');
        err_sol_Linf1 = max(abs(sol1-func));
        err_sol_Linf3 = max(abs(sol3-func));
        [err_sol_Linf1]
        [err_sol_Linf3]

        figure,
        subplot(3,1,1);
        plot(lin_data.exitflag1,'go');hold on;plot(lin_data.exitflag2,'r.');
        ylabel('exitflag');
        subplot(3,1,2);
        plot(lin_data.stdminerr);
        ylabel('min C');
        subplot(3,1,3);
        plot(lin_data.iter_numb,'r');
        ylabel('iter num');
        
    end
   
    
end

return





    
    

    
    






%% ���ݴ���


