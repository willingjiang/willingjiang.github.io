Please Run MainRBFFD_V5_Lich_v14_LBPDE_RobustProgC_V5.

EXAMPLE = 1 is full ellipse
EXAMPLE = 2 is full torus
EXAMPLE = 3 is semi-torus

UNKNOWN = 1 corresponds to analytic projection matrix and tangent vectors
UNKNOWN = 2 corresponds to approximate projection matrix and tangent vectors from 2nd-order SVD estimation
UNKNOWN = 3 corresponds to approximate projection matrix and tangent vectors from GMLS monge-parameterization estimation

One can tune the parameters in the code. In particular, one can tune the number of data points, N, to examine the convergence. 

  
