function [Matrix_Lap] = LichLocalCompute_v6p3_PolyRegr_Beltrami_V2(x,k,degr,P,tvec,operator,indexIB)

%%% Inputs
    %%% x        - N-by-n data set with N data points on d-dim M in R^n
    %%% k        - k-nearest-neighbors
    %%% degr     - degree of GMLS polynomials
    %%% P        - Nxnxn projection matrix 
    %%% tvec     - d*n*N tangent vector
    %%% operator - Laplace-Beltrami operator
    %%% indexIB  - 1 = interior, 8 = boundary 
    
%%% Outputs
    %%% Matrix_Lap - NxN Laplacian matrix
    
%%% Created by Shixiao Willing Jiang 01/01/2023    

%% k-nearest-neighbors

N = size(x,1);
n = size(x,2);
d = size(tvec,1); % tvec is d*n*N

% check all points are either interior or boundary
if sum(indexIB==1)+sum(indexIB==8) ~= N
    disp('not all points are classified as interior or boundary!');keyboard,
    return;
end

if d > 1
    index =  generatemultiindex(degr,d); % index is d*term
else
    index = 0:1:degr;
end
term = size(index,2);

% d is Nxk and contains the distances to the k nearest neighbors.
% inds is Nxk and contains the indices of the k nearest neighbors.
[~,inds] = knnCPU(x,x,k);
    
if operator == 1
    a1 = zeros(N*k,1);
    a2 = zeros(N*k,1);
    j3 = zeros(N*k,1);
end

for pp = 1:N
    
    if indexIB(pp) == 1 % interior point
        
        %% generation of PHI and its inverse        
        xx = x(inds(pp,:),:); % knn points
        x0 = x(pp,:); % center point
        pvec = tvec(:,:,pp); % pvec is d*n at center point, tvec is d*n*N
        xnorm = sqrt( sum(sum((xx-repmat(x0,k,1)).^2))/n/k );
        yy = (xx-repmat(x0,k,1))/xnorm; % k*n normalized data
        inyy = yy*pvec'; % k*d intrinsic normalized polynomial
        
        %%% Phi = [1 yy yy.^2 yy.^3 ...]
        Phi = ones(k,term); % k*term
        
        %%% contant has 1, deg 1 has d, deg 2 has (d+1)*d/2
        %%% index =  generatemultiindex(degr,d); % index is d*term
        for ss = 1:term
            for rr = 1:d
                Phi(:,ss) = Phi(:,ss).*inyy(:,rr).^index(rr,ss);
            end
        end
        
        
        %%% OLS regression
        PhiInv = (Phi'*Phi) \ Phi';
        %% differential matrix Di on coefficients c
        Gi = zeros(k,k,n); % 1st order derivative square matrix
        
        for kk = 1:n
            
            Phiprime = zeros(k,term); % k*term
            %%% second part matrix
            %         Phiprime(1:k,2:1+d) = P(inds(pp,:),:,kk)*pvec'/xnorm; % (k*n)*(n*d)
            dinyy = P(inds(pp,:),:,kk)*pvec'/xnorm; % (k*n)*(n*d)
            
            for ss = 2:term % the first term is always zero
                for rr = 1:d % derivative wrt the rr^th dimension
                    
                    if index(rr,ss) == 0
                        DiOne = zeros(k,1);
                    else
                        DiOne = ones(k,1);
                        for tt = 1:d
                            if tt == rr
                                DiOne = DiOne.*index(tt,ss).*inyy(:,tt).^(index(tt,ss)-1).*dinyy(:,tt); % the only one derivative term in monomial
                            else
                                DiOne = DiOne.*inyy(:,tt).^index(tt,ss);
                            end
                        end
                    end
                    Phiprime(:,ss) = Phiprime(:,ss) + DiOne;
                    
                end
            end
            
            %%% compute Gi = Di*Phi^-1
            Gi(:,:,kk) = Phiprime*PhiInv; % matrix product instead of .*
            
        end
        
        %% differential operator construction
        if operator == 1
            
            %%% construction of LB Matrix Locally
            matfunlocal = BeltramiLap(Gi);
            %%% give values to Matrix Boch/Hodge/Lich
            a1((pp-1)*k+(1:k),1) = pp*ones(k,1);
            a2((pp-1)*k+(1:k),1) = inds(pp,:);
            j3((pp-1)*k+(1:k),1) = matfunlocal(1,1:k);
            
        end % end for operator == 1
        
    end % end for interior point

%%% end of all points
end

if operator == 1
    %%% filter out zeros in a1,a2,j3
    indB = find(a1==0);
    a1(indB) = []; a2(indB) = []; j3(indB) = [];
    %%% Matrix_Lich local LB sparse
    Matrix_Lap = sparse(a1,a2,j3,N,N);
end

end


%% ���ݴ���





