function [Matrix_Lap,lin_data] = LichLocalCompute_v6p14_PolyRegr_RobustProg_V5_newCode(x,k0,degr,P,tvec,operator,indexIB)

%%% Inputs
    %%% x        - N-by-n data set with N data points on d-dim M in R^n
    %%% k        - k-nearest-neighbors
    %%% degr     - degree of GMLS polynomials
    %%% P        - Nxnxn projection matrix 
    %%% tvec     - d*n*N tangent vector
    %%% operator - Laplace-Beltrami operator
    %%% indexIB  - 1 = interior, 8 = boundary 
    
%%% Outputs
    %%% Matrix_Lap - NxN Laplacian matrix
    %%% lin_data   - additional optimization information 
    
%%% Created by Shixiao Willing Jiang 01/01/2023    
%%% Modified by Rongji Li, Qile Yan, John Harlim

%% k-nearest-neighbors

N = size(x,1);
n = size(x,2);
d = size(tvec,1); % tvec is d*n*N

% check all points are either interior or boundary
if sum(indexIB==1)+sum(indexIB==8) ~= N
    disp('not all points are classified as interior or boundary!');keyboard,
    return;
end

if d > 1
    index =  generatemultiindex(degr,d); % index is d*term
else
    index = 0:1:degr;
end
term = size(index,2);


if operator == 1
    a1 = zeros(N*k0,1);
    a2 = zeros(N*k0,1);
    j3 = zeros(N*k0,1);
end

%% index for optimization result
%% adaptive large enough Knn to make matrix SDD
exitflag1 = zeros(N,1); % exitflag for 1st time
exitflag2 = zeros(N,1); % exitflag for final time
stdminerr = zeros(N,1); % local min error from SDD
k2_NN_rec = zeros(N,1)+k0; % local k2-NN neighbors 
iter_numb = zeros(N,1); % iteration number
k2NNtotal = 0; % k2 increment

for pp = 1:N
    
    if indexIB(pp) == 1 % interior point
        while (1)
            %% iterative for many k and knn for w1<0
            % d is Nxk and contains the distances to the k nearest neighbors.
            % inds is Nxk and contains the indices of the k nearest neighbors.
            k = k0 + iter_numb(pp)*2;
            [~,inds0] = knnCPU(x,x(pp,:),k);
            
            %% generation of PHI and its inverse
            xx = x(inds0(1,:),:); % knn points
            x0 = x(pp,:); % center point
            pvec = tvec(:,:,pp); % pvec is d*n at center point, tvec is d*n*N
            xnorm = sqrt( sum(sum((xx-repmat(x0,k,1)).^2))/n/k );
            yy = (xx-repmat(x0,k,1))/xnorm; % k*n normalized data
            inyy = yy*pvec'; % k*d intrinsic normalized polynomial
            
            %%% Phi = [1 yy yy.^2 yy.^3 ...]
            Phi = ones(k,term); % k*term
            
            %%% contant has 1, deg 1 has d, deg 2 has (d+1)*d/2
            %%% index =  generatemultiindex(degr,d); % index is d*term
            for ss = 1:term
                for rr = 1:d
                    Phi(:,ss) = Phi(:,ss).*inyy(:,rr).^index(rr,ss);
                end
            end
            
            
            %%% OLS regression
            PhiInv = (Phi'*Phi) \ Phi';
            %% differential matrix Di on coefficients c
            Gi = zeros(k,k,n); % 1st order derivative square matrix
            
            for kk = 1:n
                
                Phiprime = zeros(k,term); % k*term
                %%% second part matrix
                %         Phiprime(1:k,2:1+d) = P(inds(pp,:),:,kk)*pvec'/xnorm; % (k*n)*(n*d)
                dinyy = P(inds0(1,:),:,kk)*pvec'/xnorm; % (k*n)*(n*d)
                
                for ss = 2:term % the first term is always zero
                    for rr = 1:d % derivative wrt the rr^th dimension
                        
                        if index(rr,ss) == 0
                            DiOne = zeros(k,1);
                        else
                            DiOne = ones(k,1);
                            for tt = 1:d
                                if tt == rr
                                    DiOne = DiOne.*index(tt,ss).*inyy(:,tt).^(index(tt,ss)-1).*dinyy(:,tt); % the only one derivative term in monomial
                                else
                                    DiOne = DiOne.*inyy(:,tt).^index(tt,ss);
                                end
                            end
                        end
                        Phiprime(:,ss) = Phiprime(:,ss) + DiOne;
                        
                    end
                end
                
                %%% compute Gi = Di*Phi^-1
                Gi(:,:,kk) = Phiprime*PhiInv; % matrix product instead of .*
                
            end
            
            %% differential operator construction
            %%% construction of LB Matrix Locally
            matfunlocal = BeltramiLap(Gi);
            
            %% linear programming for most points
            %%% x = linprog(f,A,b) solves min f'*x such that A*x �� b.
            %%% x = linprog(f,A,b,Aeq,beq) includes equality constraints Aeq*x = beq. Set A = [] and b = [] if no inequalities exist.
            %%% x = linprog(f,A,b,Aeq,beq,lb,ub) defines a set of lower and upper bounds on the design variables, x,
            %%%     so that the solution is always in the range lb �� x �� ub. Set Aeq = [] and beq = [] if no equalities exist.
            
            %%% min c with constraint Phi'*w=Phi'*a, w(1)<0, and w(k)>=-c
            %%% elsewhere, and c>=0
            f = zeros(k+1,1);
            f(k+1,1) = 1;
            %%% inequality constraints
            A = zeros(k+2,k+1);
            b = zeros(k+2,1);
            A(2:k+1,2:k+1) = -eye(k); A(2:k+1,k+1) = -ones(k,1); A(1,1) = 1; A(k+2,k+1) = 1; % SDD constraint 1
            b(k+2) = abs(min(matfunlocal(1,1:k))) + 1e-1;
            %%% equality constraints
            Aeq = zeros(term,k+1);
            Aeq(1:term,1:k) = Phi'; % Phi = k*term;
            beq = Phi'*matfunlocal(1,1:k)';
            %%% Choose the optimization algorithm after 2016b: 'dual-simplex' (default) or 'interior-point-legacy' or 'interior-point'
            %%% Choose the optimization algorithm before 2016b: 'active-set' or 'interior-point-legacy' or 'interior-point'
            options = optimset('Display', 'off','Algorithm','interior-point');
            %%% x = linprog(f,A,b,Aeq,beq,lb,ub,options) minimizes with the optimization options specified by options. Use optimoptions to set these options.
            % 3     - The solution is feasible with respect to the relative ConstraintTolerance tolerance, but is not feasible with respect to the absolute tolerance.
            % 1     - Function converged to a solution x.
            % 0     - Number of iterations exceeded options.MaxIterations or solution time in seconds exceeded options.MaxTime.
            % -2    - No feasible point was found.
            % -3    - Problem is unbounded.
            % -4    - NaN value was encountered during execution of the algorithm.
            % -5    - Both primal and dual problems are infeasible.
            % -7    - Search direction became too small. No further progress could be made.
            % -9    - Solver lost feasibility.
            [w_x0,~,exitflag] = linprog(f,A,b,Aeq,beq,[],[],options);
            
            if exitflag == 1 && abs(w_x0(k+1)/w_x0(1)) <= 0.5 % max(abs(w_x0(2:k)/w_x0(1))) <= 1
                
                %%% record all the outputs related to optimization
                if iter_numb(pp) == 0
                    exitflag1(pp) = exitflag; % if 1st time success using k-NN neighbors
                end
                exitflag2(pp) = exitflag; % the final exitflag
                stdminerr(pp) = w_x0(k+1);
                k2_NN_rec(pp) = k; % the k2-NN neighbors are used
                
                break;
                
            elseif exitflag == 1 && iter_numb(pp) > 5 % add new criterion to break 
                exitflag2(pp) = exitflag; % the final exitflag
                stdminerr(pp) = w_x0(k+1);
                k2_NN_rec(pp) = k; % the k2-NN neighbors are used                
                break;
            elseif iter_numb(pp) <= 10
                iter_numb(pp) = iter_numb(pp) + 1; % continue to iterate
            else
                disp([num2str(pp) ' th point is boundary or very poor singular, study further why!']);keyboard,
                return;
            end
            
            
        end % end while
        
        
        if operator == 1
            %%% give values to Matrix Boch/Hodge/Lich
            if iter_numb(pp) > 0
                
                %%% give values to Matrix Boch/Hodge/Lich
                a1((pp-1)*k0+(1:k0),1) = pp*ones(k0,1);
                a2((pp-1)*k0+(1:k0),1) = inds0(1,1:k0);
                j3((pp-1)*k0+(1:k0),1) = w_x0(1:k0); % j3((pp-1)*k+(1:k),1) = matfunlocal(1,1:k);
                a1(N*k0+k2NNtotal+(1:k-k0),1) = pp*ones(k-k0,1);
                a2(N*k0+k2NNtotal+(1:k-k0),1) = inds0(1,k0+1:k);
                j3(N*k0+k2NNtotal+(1:k-k0),1) = w_x0(k0+1:k);
                
                %%% update k2NNtotal
                k2NNtotal = k2NNtotal + (k-k0); % update j3count
                
            else
                a1((pp-1)*k+(1:k),1) = pp*ones(k,1);
                a2((pp-1)*k+(1:k),1) = inds0(1,:);
                j3((pp-1)*k+(1:k),1) = w_x0(1:k); % j3((pp-1)*k+(1:k),1) = matfunlocal(1,1:k);
            end
        end % end for operator == 1
        
    end % end for interior point

%%% end of all points
end

%%% function output result 1
if operator == 1
    %%% filter out zeros in a1,a2,j3
    indB = find(a1==0);
    a1(indB) = []; a2(indB) = []; j3(indB) = [];
    %%% Matrix_Lich local LB sparse
    Matrix_Lap = sparse(a1,a2,j3,N,N);
end

%%% function output result 2
lin_data.exitflag1 = exitflag1;
lin_data.exitflag2 = exitflag2;
lin_data.stdminerr = stdminerr;
lin_data.k2_NN_rec = k2_NN_rec;
lin_data.iter_numb = iter_numb;
        
end


%% ���ݴ���







