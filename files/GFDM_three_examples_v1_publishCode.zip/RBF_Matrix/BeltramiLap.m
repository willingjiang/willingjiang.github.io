function LBMat = BeltramiLap(Gi)

%%% Inputs
    %%% Gi      - NxNxn n matrices in n directions
    
%%% Outputs
    %%% BochMat - NxN, Bochner Laplace or Laplace-Beltrami 

%% compute Laplacian   
if size(Gi,1) ~= size(Gi,2)
    disp('Error: not square matrix!');
    [1 2]*[1 2];
end

N = size(Gi,1);
n = size(Gi,3);

LBMat = zeros(N,N);
for ii = 1:n
    LBMat = LBMat + Gi(:,:,ii)*Gi(:,:,ii);
end

end