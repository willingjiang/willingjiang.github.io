function [x,theta,indexIB] = semitorus_generate(DATA_INDEX,am,Ntheta,Nphi,minphi,maxphi)

% number of pts
N = Ntheta*Nphi;

%%% intrinsic data
%%% 1 == well-sampled data
%%% 2 == random data
if DATA_INDEX == 1 % well-sampled

    theta2 = 0:2*pi/Ntheta:2*pi-2*pi/Ntheta; % always [0,2*pi)
    theta2 = theta2';
    dphi = (maxphi-minphi)/(Nphi-1);
    phi2 = minphi:dphi:maxphi; % maybe [0 <2*pi]
    phi2 = phi2';
    
    [THETA,PHI] = meshgrid(theta2,phi2);
    THETA = reshape(THETA,N,1);
    PHI = reshape(PHI,N,1);
    
    indexIB = ones(N,1); % all interior
    indexIB(PHI==minphi) = 8*ones(sum(PHI==minphi),1); % setup boundary 1
    indexIB(PHI==maxphi) = 8*ones(sum(PHI==maxphi),1); % setup boundary 2
    
elseif DATA_INDEX == 2 % random

    THETA = rand(N,1)*2*pi;
    PHI = rand(N,1)*(maxphi-minphi) + minphi;
    PHI(1:Nphi) = minphi*ones(Nphi,1);
    PHI(N-Nphi+1:N) = maxphi*ones(Nphi,1);
    
    indexIB = ones(N,1); % all interior
    indexIB(PHI==minphi) = 8*ones(sum(PHI==minphi),1); % setup boundary 1
    indexIB(PHI==maxphi) = 8*ones(sum(PHI==maxphi),1); % setup boundary 2
end

%%% intrinsic data
theta = [THETA, PHI];
%%% extrinsic data
x = [(am+cos(THETA)).*cos(PHI), (am+cos(THETA)).*sin(PHI), sin(THETA)];

 

end


