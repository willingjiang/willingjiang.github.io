function [Ti] = TiCompute_v4_intd(Gi,BigT,tvec2)

%%% Inputs
    %%% Gi      - NxNxn n matrices in n directions
    %%% P0      - P0 is N*n*n projection matrix
    %%% tvec2   - tvec2 is d*n*N orthonormal tangent matrix 
    %%% BigT    - Nn*Nd matrix for tvec2
    
%%% Outputs
    %%% Si      - gradient matrix for vector field
    
%% size  
% Gi is NxNxn matrix
% P0 is Nxnxn matrix
N = size(Gi,1); % NxNxn
n = size(Gi,3);
d = size(tvec2,1);

%% construction of H_i

Ti_n = zeros(N*n,N*n);
Ti = zeros(N*d,N*d);

%%% construct the Ti matrix directly
for ii = 1:n % row of T
    for jj = 1:n % column of T
        Ti_n((ii-1)*N+(1:N),(jj-1)*N+(1:N)) = Gi(1:N,1:N,ii)*Gi(1:N,1:N,jj);
    end
end

%%% reduction intrinsic Si
Ti(:,:) = BigT' * Ti_n(:,:) * BigT;


end