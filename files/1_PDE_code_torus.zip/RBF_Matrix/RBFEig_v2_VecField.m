function [Psi,Lambda,FakeZero] = RBFEig_v2_VecField(LapMatrix,nvars,SvalThr)

%%% Inputs
    %%% LapMatrix      - Laplace Matrix N*N
    %%% nvars          - # of eigens
    %%% PhiInv         - determine the rank of matrix
    %%% SvalThr        - threashold for singular values
    
%%% Outputs
    %%% Psi            - eigenvectors
    %%% Lambda         - eigenvalues
    %%% FakeZero       - dimension of null space
    
%% detect dominant singular values     
% [~,S,~] = svd(LapMatrix);
% S = diag(S);
% S = sort(S,'ascend');
% FakeZero = length(find(S<SvalThr));

%% eigs for non-symmetric matrix
%%% find eigenvalues closest to 1 since all eigenvalues theoretically are
%%% negative definite.
[psi,lambda] = eigs(LapMatrix,nvars,1);
lambda = diag(lambda); % diagonal to vector
[~,perm] = sort(abs(lambda),'ascend');
lambda = lambda(perm);
psi = psi(:,perm);

%%% detect dominant singular values     
FakeZero = length(find(abs(lambda)<SvalThr));

%%% collect the true eigenvalues and eigenvectors
Lambda = lambda(FakeZero+1:nvars);
Psi = psi(:,FakeZero+1:nvars);

end



