function [Matrix_Boch_WS,Qhalf] = BochLap_Symmetric(Hi,Qest,BigP)

n = size(Hi,3);
Nn = size(BigP,1);

Qhalf = diag(repmat(Qest.^0.5,n,1));
QBinv = diag(repmat(Qest.^(-1),n,1));

Matrix_Boch_WS = zeros(Nn,Nn);
for ii = 1:n
    Matrix_Boch_WS = Matrix_Boch_WS + Qhalf*BigP'*Hi(:,:,ii)'*QBinv*Hi(:,:,ii)*BigP*Qhalf;
end
Matrix_Boch_WS = - Matrix_Boch_WS;

end