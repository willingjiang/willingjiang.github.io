function HodgeMat = HodgeLap(Hi,Si,Ti)

%%% Inputs
    %%% Hi      - Nn x Nn x n matrices in n directions in P23
    %%% Si      - Nn x Nn x n matrices in n directions in P23
    %%% Ti      - Nn x Nn x 1 matrices in n directions in P23
    
%%% Outputs
    %%% HodgeMat - Nn x Nn, Hodge Laplace  

%% compute Laplacian   

if (size(Hi,1) ~= size(Hi,2)) || (size(Si,1) ~= size(Si,2)) || (size(Ti,1) ~= size(Ti,2))
    disp('Error: not square matrix!');
    return;
end

Nn = size(Hi,1);
n = size(Hi,3);

HodgeMat = zeros(Nn,Nn);
for ii = 1:n
    HodgeMat = HodgeMat + Hi(:,:,ii)*(Hi(:,:,ii)-Si(:,:,ii));
end
HodgeMat = HodgeMat + Ti;

end

%% ���ݴ���
