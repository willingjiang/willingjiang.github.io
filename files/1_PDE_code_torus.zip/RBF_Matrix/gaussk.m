
classdef gaussk 
   methods(Static)
       
       function v = rbf(x2,s), v = exp(-s^2.*x2); end
       
       function d = D1(x2,s), d = -2*s^2.*exp(-s^2.*x2); end

  end % public methods

end  % class


       
