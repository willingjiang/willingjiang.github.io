function [BigT] = BigT_Compute_v4(tvec2)

%%% Compared to V1, we add right multiplication of BigP in line 42
%%% Compared to V2, we reduce from n to d for Hi, using tvec2, not P0
%%% Compared to V3, we put contruction of BigT outside 

%%% Inputs
    %%% Gi      - NxNxn n matrices in n directions
    %%% P0      - P0 is N*n*n projection matrix
    %%% tvec2   - tvec2 is d*n*N orthonormal tangent matrix 
    
%%% Outputs
    %%% Hi      - gradient matrix for vector field
    %%% BigP    - (N*n)x(N*n), Big projection matrix
    
d = size(tvec2,1);
n = size(tvec2,2);
N = size(tvec2,3);

%% construction of big P

a1 = zeros(N*n*d,1);
a2 = zeros(N*n*d,1);
j3 = zeros(N*n*d,1);

%%% row and col of matrix BigP
for ii = 1:n
    for jj = 1:d
        %%% BigP((ii-1)*N+1:ii*N,(jj-1)*N+1:jj*N) = diag(P0(:,ii,jj));
        a1(((ii-1)*d+(jj-1))*N+(1:N),1) = (ii-1)*N + (1:N);
        a2(((ii-1)*d+(jj-1))*N+(1:N),1) = (jj-1)*N + (1:N);
        j3(((ii-1)*d+(jj-1))*N+(1:N),1) = tvec2(jj,ii,1:N);
    end
end
BigT = sparse(a1,a2,j3,N*n,N*d);

end