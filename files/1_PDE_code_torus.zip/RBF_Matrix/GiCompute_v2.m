function [Gi,PhiInv,dPhi] = GiCompute_v2(x,s,P,SvalThr,kerflag)

%%% Inputs
    %%% x       - N-by-n data set with N data points on d-dim M in R^n
    %%% s       - shape paremter of kernel
    %%% P       - Nxn-xn little pi for i=1..n 
    
%%% Outputs
    %%% Gi      - NxNxn n matrices in n directions
    %%% PhiInv  - NxN interpolant matrix 
    %%% gX2     - NxN phi'(-s*r^2)/r
    
%% derivative of basis function
% syms x2 % x2 is square of distance
% f = @(x2)exp(-s*x2); % basis is exp(-s*x^2)
% %%% g(x2) = 2*diff(f,x2); 
% g = @(x2)(-2*s*exp(-s*x2)); % 2*d_basis = phi'(-s*r^2)/r to cancel the r term

%%% 1 == Gauss
%%% 2 == inverse quadratic 1/(1+s^2*r^2)
if kerflag == 1
    mat = gaussk();
elseif kerflag == 2
    mat = iqk();
end

%% PHI inverse

%%% X is pairwise distance
X = pdist2(x,x);

% Phi = f(X.^2); % Phi = exp(-s*X.^2). Phi is NxN
Phi = mat.rbf(X.^2,s); % Phi = exp(-s*X.^2). Phi is NxN, RBF system matrix

PhiInv = pinv(Phi,SvalThr);

%% differential matrix Di on coefficients c

N = size(x,1);
n = size(x,2);
Gi = zeros(N,N,n);

%%% output gX2 for covariant derivative
% dPhi = g(X.^2);
% dphi = @(x2)(-2*s*exp(-s*x2)); % 2*d_basis = phi'(-s*r^2)/r to cancel the r term
dPhi = mat.D1(X.^2,s);

for kk = 1:n
    
    %%% compute p_i^T * (x - x_k)
    Di = zeros(N,N);
    for ii = 1:N
        diffx = x - repmat(x(ii,:),N,1); % N*n
        Di(:,ii) = sum(diffx.*P(:,:,kk),2);
    end
    %%% compute p_i^T * (x - x_k) .* (phi'/rk)
    Phiprime = Di.*dPhi; % here is .* %%% use eval(g(X.^2)) if g is syms
    %%% compute Gi = Di*Phi^-1
    Gi(:,:,kk) = Phiprime*PhiInv; % matrix product instead of .*

end



end


%% ���ݴ���

% diffx = repmat(x,1,length(x)) - repmat(x',length(x),1);
% Phiprime = Phi.*(-2*s*diffx);
% fprimehat = Phiprime*c;




