function [Si] = SiCompute(Gi,P0)

%%% Inputs
    %%% Gi      - NxNxn n matrices in n directions
    %%% P0      - P0 is N*n*n projection matrix
    
%%% Outputs
    %%% Si      - gradient matrix for vector field
    
%% size    
N = size(Gi,1); % NxNxn
n = size(Gi,3);
% Gi is NxNxn matrix
% P0 is Nxnxn matrix

%% construction of H_i

Si = zeros(N*n,N*n,n);

for kk = 1:n % S_k
    for ii = 1:n % row of S
        for jj = 1:n % column of S
            diagS = P0(:,jj,kk);
            Si((ii-1)*N+(1:N),(jj-1)*N+(1:N),kk) = diag(diagS)*Gi(1:N,1:N,ii);
        end
    end
end



end