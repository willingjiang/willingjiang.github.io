function [Hi,BigP] = HiCompute(Gi,P0)

%%% Inputs
    %%% Gi      - NxNxn n matrices in n directions
    %%% P0      - P0 is N*n*n projection matrix
    
%%% Outputs
    %%% Hi      - gradient matrix for vector field
    %%% BigP    - (N*n)x(N*n), Big projection matrix
    
%% size    
N = size(Gi,1);
n = size(Gi,3);

%% construction of big P

a1 = zeros(N*n*n,1);
a2 = zeros(N*n*n,1);
j3 = zeros(N*n*n,1);

%%% row and col of matrix BigP
for ii = 1:n
    for jj = 1:n
        %%% BigP((ii-1)*N+1:ii*N,(jj-1)*N+1:jj*N) = diag(P0(:,ii,jj));
        a1(((ii-1)*n+(jj-1))*N+(1:N),1) = (ii-1)*N + (1:N);
        a2(((ii-1)*n+(jj-1))*N+(1:N),1) = (jj-1)*N + (1:N);
        j3(((ii-1)*n+(jj-1))*N+(1:N),1) = P0(1:N,ii,jj);
    end
end
BigP = sparse(a1,a2,j3,N*n,N*n);

%% construction of H_i

Hi = zeros(N*n,N*n,n);

for kk = 1:n
    for ss = 1:n
        Hi((ss-1)*N+(1:N),(ss-1)*N+(1:N),kk) = Gi(1:N,1:N,kk);
    end
    Hi(:,:,kk) = BigP * Hi(:,:,kk);
end



end