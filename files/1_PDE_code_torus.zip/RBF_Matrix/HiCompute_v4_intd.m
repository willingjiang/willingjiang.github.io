function [Hi] = HiCompute_v4_intd(Gi,BigT,tvec2)

%%% Compared to V1, we add right multiplication of BigP in line 42
%%% Compared to V2, we reduce from n to d for Hi, using tvec2, not P0
%%% Compared to V3, we put contruction of BigT outside 

%%% Inputs
    %%% Gi      - NxNxn n matrices in n directions
    %%% P0      - P0 is N*n*n projection matrix
    %%% tvec2   - tvec2 is d*n*N orthonormal tangent matrix 
    %%% BigT    - Nn*Nd matrix for tvec2
    
%%% Outputs
    %%% Hi      - gradient matrix for vector field
    %%% BigP    - (N*n)x(N*n), Big projection matrix
    
%% size    
N = size(Gi,1);
n = size(Gi,3);
d = size(tvec2,1);

%% construction of H_i

Hi = zeros(N*d,N*d,n);
Hi_n =  zeros(N*n,N*n,n);

for kk = 1:n
    for ss = 1:n
        Hi_n((ss-1)*N+(1:N),(ss-1)*N+(1:N),kk) = Gi(1:N,1:N,kk);
    end
    Hi(:,:,kk) = BigT' * Hi_n(:,:,kk) * BigT;
end



end