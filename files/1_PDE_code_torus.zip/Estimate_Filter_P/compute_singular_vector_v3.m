function [Un] = compute_singular_vector_v3(x,x0,k, epsilon)

%%% Inputs
    %%% x       - N-by-[n_R] data set with N data points in R^n_R
    %%% x0      - 1-by-[n_R]. 1 target data point in R^n_R
    %%% k       - number of nearest neighbors to use
        
%%% Outputs
    %%% epss    - All possible value of epsilon. The size is
    %%%             1*[length(epss)]. ��1��
    %%% epsind  - index of final epsilon value. epsilon = epss(epsind).
    %%% sigma2  - SVD values of local X=dexp'. The size is
    %%%             n_R*[length(epss)]. ��1��
    %%% alpha2  - scaling law satisfying sigma2 is proportional to
    %%%             epsilon^alpha2. The size is n_R*[length(epss)-1].  ��2��  
    %%% d1eps   - 1st estimate of intrinsic dimension of the manifold lying
    %%%             inside R^n_R. Size is 1*[length(epss)]. ��1��
    %%% d2eps   - 2nd estimate of intrinsic dimension of the manifold lying
    %%%             inside R^n_R. Size is 1*[length(epss)-1]. ��2��
    %%% dave    - final estimate of intrinsic dimension of the manifold
    %%%             lying inside R^n_R. dave = (d1eps + d2eps)/2. Size is
    %%%             1*[length(epss)-1]. ��2�� 

    %%% ��1�� denotes that the column length of matrix is [length(epss)]
    %%% ��2�� denotes that the column length of matrix is [length(epss)-1]
    %%% Epsilon tuning at xi by using the local kernel in IDM paper.

%% k nearest neighbors

    [~,n_R] = size(x); %number of points

    [~,inds] = knnCPU(x,x0,k); % index of k nearest neighbors of the x0 point

%     epsilon = epss(epsind);

%% Constructing X' (dexp) , then compute SVD values (sigma2), 1st intrinsic dimension d1 (d1eps), scaling law alpha_l (alpha2)
    d = x(inds,:) - repmat(x0,k,1); % k*n_R. d = xi - x.
    dn = sum(d.^2,2); % k*1. norm ||xi-x||^2.

   
    dexp = exp(-dn./4/epsilon); % k*1
    dexp = repmat(dexp,1,n_R).*d; % k*n_R
    
    dexp2 = exp(-dn./2/epsilon); % k*1
    
    dexp = (sum(dexp2)).^(-0.5).*dexp; % k*n_R = X' in paper
    
    % svd value of X = dexp'
    [Un,si,~] = svd(dexp'); % dexp' is n_R*k
    [~,IX] = sort(diag(si),'descend');
    Un = Un(:,IX);
% keyboard,

    
end


