function [P0_low] = P0_filter_v6_pinv(P0_tilde,dlow,dim)

%%% Inputs
    %%% P0_tilde       - Kernel rough Projection Matrix N*n*n
    %%% nlow           - # of low k modes
    %%% psi2           - DM eigenvectors
    %%% peq            - DM weight
    %%% qest           - DM sampling density
    %%% dim            - dimension of manifold
    
%%% Outputs
    %%% P0_low         - filtered P
    %%% ck_all         - coefficient of P0_tilde(:,n,n) to see how many
    %%%                  modes to be preserved
    
N = size(P0_tilde,1);
n = size(P0_tilde,2);

P0_low = zeros(N,n,n);
for ii = 1:n
    for jj = 1:n
        P0_low(:,ii,jj) = dlow*P0_tilde(:,ii,jj);
    end
end

%%% normalization of P0 matrix
%%% P0_low_2 is n*n*N
P0_low_2 = permute(P0_low,[3,2,1]); 
for ii = 1:N
    [Un,~,~] = svd(P0_low_2(:,:,ii)); % [Un,Si,~] = svd(P0_low_2(:,:,ii));
    P0_low_2(:,:,ii) = Un(:,1:dim)*Un(:,1:dim)'; % normalized smooth tangent 
end
P0_low = permute(P0_low_2,[3,2,1]); % P0_low is N*n*n

end





