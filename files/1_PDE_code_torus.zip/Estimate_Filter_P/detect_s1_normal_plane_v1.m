function [tangent,P0_tilde] = detect_s1_normal_plane_v1(x,indxB, kk,dim)

%%% input 
    %%% x          - manifold data
    %%% indxB      - index of point that needs the tangent space to compute
    %%% kk         - # of knn
    %%% dim        - intrinsic dimension of manifold (surface)

%%% output
    %%% tangent    - tangent space at given point, n*d*NBL
    %%% P0_tilde   - estimated projection matrix, NBL*n*n

n = size(x,2);

NBL = length(indxB);
Un_L = zeros(n,n,NBL);

for ii = 1:NBL
    %%% epsilon local tuning
    [~,inds] = knnCPU(x,x(indxB(ii),:),kk);
    [~,epsilon] = qestfind(x(inds,:),kk);
    [Un_L(:,:,ii)] = compute_singular_vector_v3(x,x(indxB(ii),:), kk,epsilon);
end

%%% numerically find all tangent space
tangent = Un_L(:,1:dim,:); % size is n*dim*NBL

P0_tilde = zeros(n,n,NBL);
for ii = 1:NBL
    P0_tilde(:,:,ii) = tangent(:,:,ii)*tangent(:,:,ii)';
end
P0_tilde = permute(P0_tilde,[3,2,1]); % P0 is N*n*n

end

%% ���ݴ���

    %%% epsilon local tuning (old)
%     [epss,epsind,sigma2,alpha2,d1eps,d2eps,dave,inds] = Func_eps_x_SVD(x,x(indx_1_L(ii),:),kk);
%     epsilon = epss(epsind);
