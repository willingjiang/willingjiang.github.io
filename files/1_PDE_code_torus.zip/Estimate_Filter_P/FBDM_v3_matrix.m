function [dlow] = FBDM_v3_matrix(x,k,operator,DinvThr,epsilon)

%%% Inputs
    %%% x       - N-by-n data set with N data points in R^n
    %%% k       - number of nearest neighbors to use
    %%% nvars   - number of eigenfunctions/eigenvalues to compute
    %%% dim     - intrinsic dimension of the manifold lying inside R^n
    %%% epsilon - optionally choose an arbitrary "global" epsilon
    
%%% Outputs
    %%% q_vector- Eigenfunctions of the generator/Laplacian
    %%% lambda  - Eigenvalues
    %%% epsilon - scale, derived from the k2 nearest neighbors
    %%% qest    - Sampling measure
    %%% dim     - estimated intrinsic dimension of the manifold lying inside R^n

    
    %%% Theory requires c2 = 1/2 - 2*alpha + 2*dim*alpha + dim*beta/2 + beta < 0 
    %%% The resulting operator will have c1 = 2 - 2*alpha + dim*beta + 2*beta
    %%% Thus beta = (c1/2 - 1 + alpha)/(dim/2+1), since we want beta<0,
    %%% natural choices are beta=-1/2 or beta = -1/(dim/2+1)
    %%% For fixed bandwidth DM, alpha = 1/2, beta = 0.
%% Step 1: estimate the tuned final dim, and tuned final epsilon    
    N = size(x,1); %number of points
    
    % d is Nxk and contains the distances to the k nearest neighbors.
    % inds is Nxk and contains the indices of the k nearest neighbors.
    [d,inds] = knnCPU(x,x,k);
    
    %%% Build ad hoc bandwidth function by autotuning epsilon for each pt.
    epss = 2.^(-30:.1:10); % the whole potential range of epss{epsilon}
    
    %%% Pre-kernel used with ad hoc bandwidth only for estimating dimension
    %%% and sampling density
    d = d.^2.; % d^2
    % d value is squared first time.
    
    %%% Tune pre-epsilon on the pre-kernel
    dpreGlobal=zeros(1,length(epss));
    for i=1:length(epss)
        dpreGlobal(i) = sum(sum(exp(-d./(4*epss(i))),2))/(N*k); % based on S(eps) = 1/N^2 * sum(sum(Kij)) = (4*pi*eps)^(d/2)     
        % should be equal to (4*pi*epsilon)^(d/2)
    end
   
    [maxval,maxind] = max(diff(log(dpreGlobal))./diff(log(epss)));
    % plot(log(epss),log(dpreGlobal)); %%% plot the relation bw log(eps) and log(S(eps)), to find the linearity region. 
    
    %%% the estimated final dim
    if (nargin < 6)
        dim=2*maxval
    end
    % plot(log(epss),log(dpreGlobal)-dim/2*log(epss)); %%% plot the relation bw log(eps) and log(S(eps)), to find the linearity region. 
    
    %%% Tune final epsilon for the final kernel, the estimated final epsilon
    %%% determine the final epsilon by using the kernel with the fixed bandwidth function.
    if (nargin < 5)        
        %%% choice 1, original code, treat the maxind as the index of value
        %%% epss
        epsilon = epss(maxind)
        
        %%% choice 2, the local epss(maxind) may be too sensitive
        %%% Since DG=log(dpreGlobal(maxind))-dim/2*log(epss(maxind)) should be
        %%% a constant around a epss region, then we use the maximal epss
        %%% value satisfying that DG is a constant (practically to choose a epss(i)=DG-abs(DG)*0.01). 
%         maxIntercept = log(dpreGlobal(maxind))-dim/2*log(epss(maxind));
%         maxIntercept = maxIntercept-abs(maxIntercept)*0.01;
%         for i=maxind:length(epss)
%             preIntercept = log(dpreGlobal(i))-dim/2*log(epss(i));
%             if preIntercept < maxIntercept
%                 break;
%             end
%         end
%         epsilon = epss(i)
    end
    
    
%% Step 2: give alpha and beta to determine ([1] Kolmogorov backward operator, c1 = 1, vs. [2] Laplace-Beltrami, c1 = 0). 
%% operator == 3 is Laplace-Beltrami operator fixed bandwidth
%% operator == 4 is Kolmogorov backward operator fixed bandwidth 
 
    if (operator == 3)
        %%% Laplace Beltrami, fixed bandwidth
%         beta = 0;
        alpha = 1;
    elseif (operator == 4)
        %%% Kolmogorov backward operator, fixed bandwidth
%         beta = 0;
        alpha = 1/2;
    end
    
    %%% c1 = 2 - 2*alpha + dim*beta + 2*beta; % c1 = 1, Kolmogorov backward operator
    %%% operator = Lap + c1*grad(q)/q*grad
    %%% c2=.5-2*alpha+2*dim*alpha+dim*beta/2+beta; % c2 = -0.5+d >0. However, typically c2 < 0 is required to control error
    
%% Step 3.1: the "right" normalization       
%% define the final kernal using final epsilon
    %%% K_epsilon with final choice of epsilon
    d = exp(-d./(4*epsilon));

    d = sparse(reshape(double(inds'),N*k,1),repmat(1:N,k,1),reshape(double(d'),N*k,1),N,N,N*k)';
    
    %%% symmetrize since this is the symmetric formulation
    %%% d = K_epsilon
    d = (d+d')/2;  
    
    %%% qest = q_epsilon, final qest, (this is the sampling density estimate q(x) obtained from VB kernel)
    qest = full(sum(d,2));

    %%% Dinv1 = q_epsilon {^} (-alpha). needed part in "right" normalization
    Dinv1 = spdiags(qest.^(-alpha),0,N,N);

    %%% d = K_{epsilon} ^ \hat
    %%% this d is symmetric [K_{epsilon} ^ \hat]
    d = Dinv1*d*Dinv1; % the "right" normalization   
    d = (d+d')/2;
    
%% Step 3.2: the "left" normalization    
%% compute the symmetric Kolmogorov-Backward matrix, L_epsilon ^ \hat    
    %%% peqoversample = D, where 
    %%% D_ii = q_epsilon ^ {\hat} = sum(d,2)/N
    peqoversample = full(sum(d,2));
       
    %%% Dinv3 = D^(-1)
    Dinv3 = spdiags(peqoversample.^(-1),0,N,N);
    %%% D3 = D^(+1)
    D3 = spdiags(peqoversample.^(+1),0,N,N);
    
    %%% pseudo inverse of d = K_epsilon^\hat
    dinv = pinv(full(d),DinvThr);
    
    %%% low pass filter is D^-1*K*inv(K)*D
    dlow = Dinv3*d*dinv*D3;
    
%     %%% Dinv2 = D^(-1/2)
%     Dinv2 = spdiags(peqoversample.^(-1/2),0,N,N);
%     
%     %%% d = 1 + epsilon * L_epsilon^\hat 
%     %%% L_epsilon^\hat = [D^(-1/2)*K_epsilon^{\hat}*D^(-1/2) - I] / epsilon
%     %%% Therefore, d = D^(-1/2)*K_epsilon^{\hat}*D^(-1/2) 
%     d = Dinv2*d*Dinv2 ; %%% "left" normalization
% 
%     d = (d+d')/2;
    
end