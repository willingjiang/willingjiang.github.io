function [Matrix_Hodge] = Main_HodgeMatrix_V2_intd(ManifoldParam,RoughKernel,LowPassFilter,ProjMat_INDEX,RBFEigenValue)

%%% Inputs
    %%% ManifoldParam     - d,n,N
    %%% DATA_INDEX        - well-sampled or random data
    %%% RoughKernel       - parameters for rough projection matrix P0_tilde
    %%% LowPassFilter     - parameters for filter projection matrix P0_low
    %%% ProjMat_INDEX     - which P0,P0_tilde,P0_low to be used
    %%% am                - length of ellipse
    %%% s                 - shape parameter of basis function
    %%% SvalThr           - threashold for inverse of RBF matrix
    %%% c                 - definite for solving PDE
    
%%% Outputs
    %%% OutPut.theta      - intrinsic coordinate    
    %%% OutPut.upp_vec    - True N*n Bochner Laplacian of u
    %%% OutPut.Boch_u_vec - Numerical N*n Bochner Laplacian of u
    %%% OutPut.u_vec      - True N*n solution u
    %%% OutPut.u_num_vec  - Numerical N*n solution u
    

%% Input parameters

addpath ./Estimate_Filter_P
addpath ./Manifold_Info
addpath ./RBF_Matrix

%% data input
%%% manifold parameter
d = ManifoldParam.d;
n = ManifoldParam.n;
% N = ManifoldParam.N;
% am = ManifoldParam.am;

x = ManifoldParam.x;
% theta = ManifoldParam.theta;
P0 = ManifoldParam.P0;
tvec2 = ManifoldParam.tvec2;

%% RBF eigenvalue parameters 

%%% given basis function
s = RBFEigenValue.s;

%%% threashold for singular values in Gi for RBF interpolant
SvalThr = RBFEigenValue.SvalThr;

%%% kerflag 
%%% 1 == Gauss
%%% 2 == inverse quadratic 1/(1+s^2*r^2)
kerflag = RBFEigenValue.kerflag;

%%% # of eigenvalues to compute
% nvars = RBFEigenValue.nvars;
%%% threashold for eigenvalue in Bochner matrix
% EigvalThr = RBFEigenValue.EigvalThr;

%% construction of Projection P

Pmatrix = projmatrix_generate(ProjMat_INDEX,x, P0,d,LowPassFilter,RoughKernel);

%% construction of big P and Hi

[Gi] = GiCompute_v2(x,s,Pmatrix,SvalThr,kerflag);
[BigT] = BigT_Compute_v4(tvec2);

%%% [Hi] = HiCompute_v2(Gi,Pmatrix);
%%% [Hi] = HiCompute_v3_intd(Gi,tvec2);
[Hi] = HiCompute_v4_intd(Gi,BigT,tvec2);
[Si] = SiCompute_v4_intd(Gi,BigT,tvec2,Pmatrix);
[Ti] = TiCompute_v4_intd(Gi,BigT,tvec2);

Matrix_Hodge = HodgeLap(Hi,Si,Ti);

% Matrix_Boch = BochLap(Hi);
% Matrix_LB = BochLap(Gi);



end


%% ���ݴ���


