function [EigValue_sphere,EigFunc_sphere,THETA] = circle_eigen_mod(Ntheta,nvars)

%%% Input
    %%% a        - a > 1 radius of larger circle
    %%% Nphi     - # points of phi on [0,2pi]
    %%% Ntheta0  - # points of theta on [0,2pi)
    %%% Nrefine  - # points of refinement of theta for finite difference

    %%% nvtheta  - # eigenfunctions of theta
    %%% nvphi    - # eigenfunctions of phi
    %%% nvars    - # eigenfunctions of the torus

%%% Output
    %%% EigValue_torus - torus eigenvalue
    %%% EigFunc_torus  - torus eigenfunction
    %%% THETA          - column domain THETA
    %%% PHI            - column domain PHI 

%%% phi = [0,pi) or [0,2*pi)
%%% theta = [0,2*pi)

if mod(nvars,2) == 0
    nvars = nvars + 1;
end

%% eigenfunction of Theta for theta in [0,2*pi) 
THETA = (0:1/Ntheta:1-1/Ntheta)'*2*pi; % [0,2*pi)

%% spherical harmonic eigenfunction
EigFunc_sphere = zeros(Ntheta,nvars);
EigValue_sphere = zeros(nvars,1);

for ii = 1:nvars
    if ii == 1
        EigValue_sphere(ii,1) = 0;
        EigFunc_sphere(:,ii) = EigFunc_sphere(:,ii) + 1;
    elseif mod(ii,2) == 0
        EigValue_sphere(ii,1) = -(ii/2)^2;
        EigFunc_sphere(:,ii) = sqrt(2)*cos((ii/2)*THETA);
    elseif mod(ii,2) == 1
        EigValue_sphere(ii,1) = -((ii-1)/2)^2;
        EigFunc_sphere(:,ii) = sqrt(2)*sin(((ii-1)/2)*THETA);
    end
end

end



