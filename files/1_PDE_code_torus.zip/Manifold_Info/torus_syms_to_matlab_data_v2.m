function [u_true_col,upp_true_col,U_col,Upp_col_true] = torus_syms_to_matlab_data_v2(theta,tvec2,F2_1,F2_2,am,u1_vec,u2_vec)

%%% Compared to v1, more 2 outputs are the TRUE sol U_col and TRUE
%%% Laplacian Upp_col_true
%%% Note that since tvec2 is numerics, sol u_true_col and Laplacian
%%% upp_true_col are also numerical approx.

%%% Inputs
    %%% x        - N-by-n data set with N data points on d-dim M in R^n
    %%% theta    - N-by-d data
    %%% tvec2    - dxnxN global orthonormal basis  
%     % trivial is u1=0,u2=1.
%     % nontrivial is u1=1,u2=0.
%     u1 = 1; % symbolic, u1 = sin(theta2);
%     u2 = 0;
%     % corresponding vector for numerics
%     u1_vec = 1; % numerics, u1_vec = sin(theta(:,1));
%     u2_vec = 0;
%     [f1,f2]=Vec_2d(theta2,phi2,g,u1,u2,operator);
%     F2_1 = matlabFunction(f1); % @(phi,theta) or @()0.0
%     F2_2 = matlabFunction(f2); % @(phi,theta) or @()0.0
    
%%% Outputs
    %%% u_true_col   - Ndx1 true vector field
    %%% upp_true_col - Ndx1 true Laplacian vector field
    
%%% Created by Shixiao Willing Jiang 01/14/2025   

N = size(theta,1);
d = size(theta,2);
n = 3;

%%% syms to matlab data
if nargin(F2_1) == 0
    b1 = theta(:,1)*F2_1();
else
    b1 = F2_1(theta(:,2),theta(:,1)); % F2_1(phi2,theta2)
end
if nargin(F2_2) == 0
    b2 = theta(:,1)*F2_2();
else
    b2 = F2_2(theta(:,2),theta(:,1));
end

ddtheta_1 = -sin(theta(:,1)).*cos(theta(:,2));
ddtheta_2 = -sin(theta(:,1)).*sin(theta(:,2));
ddtheta_3 = cos(theta(:,1));

ddphi_1 = -(am+cos(theta(:,1))).*sin(theta(:,2));
ddphi_2 = (am+cos(theta(:,1))).*cos(theta(:,2));
ddphi_3 = theta(:,1)*0;

Upp_col_true = zeros(N*n,1);
Upp_col_true((1:N)+0*N,1) = b1.*ddtheta_1 + b2.*ddphi_1;
Upp_col_true((1:N)+1*N,1) = b1.*ddtheta_2 + b2.*ddphi_2;
Upp_col_true((1:N)+2*N,1) = b1.*ddtheta_3 + b2.*ddphi_3;

%%% True solution
U_col = zeros(N*n,1);
U_col((1:N)+0*N,1) = u1_vec.*ddtheta_1 + u2_vec.*ddphi_1;
U_col((1:N)+1*N,1) = u1_vec.*ddtheta_2 + u2_vec.*ddphi_2;
U_col((1:N)+2*N,1) = u1_vec.*ddtheta_3 + u2_vec.*ddphi_3;

%%% intrinsic representation (projection) of true solution and vector Laplacian
u_true_col = zeros(N*d,1);
for ii = 1:d
    for jj = 1:n
        % u1(x1:xN) u2(x1:xN) u3(x1:xN)
        u_true_col((1:N)+(ii-1)*N,1) = u_true_col((1:N)+(ii-1)*N,1) + U_col((1:N)+(jj-1)*N,1).*squeeze(tvec2(ii,jj,:));
    end
end

upp_true_col = zeros(N*d,1);
for ii = 1:d
    for jj = 1:n
        % u1(x1:xN) u2(x1:xN) u3(x1:xN)
        upp_true_col((1:N)+(ii-1)*N,1) = upp_true_col((1:N)+(ii-1)*N,1) + Upp_col_true((1:N)+(jj-1)*N,1).*squeeze(tvec2(ii,jj,:));
    end
end

end