function [EigVector_circle] = circle_eigen_vector(EigFunc_sphere,THETA)

%%% Input
    %%% a        - a > 1 radius of larger circle
    %%% Nphi     - # points of phi on [0,2pi]
    %%% Ntheta0  - # points of theta on [0,2pi)
    %%% Nrefine  - # points of refinement of theta for finite difference

    %%% nvtheta  - # eigenfunctions of theta
    %%% nvphi    - # eigenfunctions of phi
    %%% nvars    - # eigenfunctions of the torus

%%% Output
    %%% EigValue_torus - torus eigenvalue
    %%% EigFunc_torus  - torus eigenfunction
    %%% THETA          - column domain THETA
    %%% PHI            - column domain PHI 

%%% phi = [0,pi) or [0,2*pi)
%%% theta = [0,2*pi)

n = 2;
Ntheta = size(EigFunc_sphere,1);
nvars = size(EigFunc_sphere,2);

EigVector_circle = zeros(Ntheta*n,nvars);

for ii = 1:nvars
    EigVector_circle((1:Ntheta)+Ntheta*0,ii) = EigFunc_sphere(:,ii).*(-sin(THETA));
    EigVector_circle((1:Ntheta)+Ntheta*1,ii) = EigFunc_sphere(:,ii).*(+cos(THETA));
end



end



