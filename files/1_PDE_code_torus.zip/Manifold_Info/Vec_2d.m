function [f1,f2]=Vec_2d(theta,phi,g,u1,u2,operator)
%%% find the symbolic expression of the Bochner Laplacian
%%% euqation in local coordinates: [f1,f2]= \Boch u
%% Input: 
% theta,phi: intrinsic coordinates
% g: Riemannian metric
% u1 \partial/\partial theta + u2 \partial/\partial phi
%% Output:
% forcing term: f1 \partial/\partial theta + f2 \partial/\partial phi
% \Boch u = g^ij u^k_ij \partial/\partial theta^k

g_inv=inv(g); % inverse of Riemannian metric

%% Christoffel symbols \Gamma^k_{ij}:= ch_k_ij
ch_1_11=0.5*(g_inv(1,1)*diff(g(1,1),theta)+g_inv(1,2)*(2*diff(g(1,2),theta)-diff(g(1,1),phi)));
ch_1_12=0.5*(g_inv(1,1)*diff(g(1,1),phi)+g_inv(1,2)*diff(g(2,2),theta));
ch_1_21=ch_1_12;
ch_1_22=0.5*(g_inv(1,1)*(2*diff(g(2,1),phi)-diff(g(2,2),theta))+g_inv(1,2)*diff(g(2,2),phi));
ch_2_11=0.5*(g_inv(2,1)*diff(g(1,1),theta)+g_inv(2,2)*(2*diff(g(1,2),theta)-diff(g(1,1),phi)));
ch_2_12=0.5*(g_inv(2,1)*diff(g(1,1),phi)+g_inv(2,2)*diff(g(2,2),theta));
ch_2_21=ch_2_12;
ch_2_22=0.5*(g_inv(2,1)*(2*diff(g(2,1),phi)-diff(g(2,2),theta))+g_inv(2,2)*diff(g(2,2),phi));

%% coefficients of covariant derivative u^i_{;j}:=u_i_j
u_1_1=diff(u1,theta)+u1*ch_1_11+u2*ch_1_12;
u_1_2=diff(u1,phi)+u1*ch_1_21+u2*ch_1_22;
u_2_1=diff(u2,theta)+u1*ch_2_11+u2*ch_2_12;
u_2_2=diff(u2,phi)+u1*ch_2_21+u2*ch_2_22;

%% coefficients of total covariant derivative of u, u^{i}_{;jk}:=u_i_jk
u_1_11=diff(u_1_1,theta)+(u_1_1*ch_1_11+u_2_1*ch_1_12)-(u_1_1*ch_1_11+u_1_2*ch_2_11);
u_1_12=diff(u_1_1,phi)+(u_1_1*ch_1_21+u_2_1*ch_1_22)-(u_1_1*ch_1_21+u_1_2*ch_2_21);
u_1_21=diff(u_1_2,theta)+(u_1_2*ch_1_11+u_2_2*ch_1_12)-(u_1_1*ch_1_12+u_1_2*ch_2_12);
u_1_22=diff(u_1_2,phi)+(u_1_2*ch_1_21+u_2_2*ch_1_22)-(u_1_1*ch_1_22+u_1_2*ch_2_22);
u_2_11=diff(u_2_1,theta)+(u_1_1*ch_2_11+u_2_1*ch_2_12)-(u_2_1*ch_1_11+u_2_2*ch_2_11);
u_2_12=diff(u_2_1,phi)+(u_1_1*ch_2_21+u_2_1*ch_2_22)-(u_2_1*ch_1_21+u_2_2*ch_2_21);
u_2_21=diff(u_2_2,theta)+(u_1_2*ch_2_11+u_2_2*ch_2_12)-(u_2_1*ch_1_12+u_2_2*ch_2_12);
u_2_22=diff(u_2_2,phi)+(u_1_2*ch_2_21+u_2_2*ch_2_22)-(u_2_1*ch_1_22+u_2_2*ch_2_22);
%% Lichnerowicz_Laplacian L_u=L_u1\partial/\partial theta+L_u2\partial/\partial phi
if operator == 2
    L_u1=g_inv(1,1)*u_1_11+g_inv(1,2)*u_1_21+g_inv(2,1)*u_1_12+g_inv(2,2)*u_1_22;
    L_u2=g_inv(1,1)*u_2_11+g_inv(1,2)*u_2_21+g_inv(2,1)*u_2_12+g_inv(2,2)*u_2_22;
elseif operator == 3
    L_u1=g_inv(1,1)*u_1_11+g_inv(1,2)*u_1_21+g_inv(2,1)*u_1_12+g_inv(2,2)*u_1_22;
    L_u1=L_u1-(g_inv(1,1)*u_1_11+g_inv(1,1)*u_2_12+g_inv(2,1)*u_1_21+g_inv(2,1)*u_2_22);
    L_u1=L_u1+(g_inv(1,1)*u_1_11+g_inv(1,1)*u_2_21+g_inv(2,1)*u_1_12+g_inv(2,1)*u_2_22);
    L_u2=g_inv(1,1)*u_2_11+g_inv(1,2)*u_2_21+g_inv(2,1)*u_2_12+g_inv(2,2)*u_2_22;
    L_u2=L_u2-(g_inv(1,2)*u_1_11+g_inv(1,2)*u_2_12+g_inv(2,2)*u_1_21+g_inv(2,2)*u_2_22);
    L_u2=L_u2+(g_inv(1,2)*u_1_11+g_inv(1,2)*u_2_21+g_inv(2,2)*u_1_12+g_inv(2,2)*u_2_22);
elseif operator == 4
    L_u1=g_inv(1,1)*u_1_11+g_inv(1,2)*u_1_21+g_inv(2,1)*u_1_12+g_inv(2,2)*u_1_22;
    L_u1=L_u1+g_inv(1,1)*u_1_11+g_inv(1,1)*u_2_12+g_inv(2,1)*u_1_21+g_inv(2,1)*u_2_22;
    L_u2=g_inv(1,1)*u_2_11+g_inv(1,2)*u_2_21+g_inv(2,1)*u_2_12+g_inv(2,2)*u_2_22;
    L_u2=L_u2+g_inv(1,2)*u_1_11+g_inv(1,2)*u_2_12+g_inv(2,2)*u_1_21+g_inv(2,2)*u_2_22;
end
%% Righthand side forcing term f
f1=L_u1;
f2=L_u2;

end