function [tvec_rot] = torus_tvec_rot(tvec2)

N = size(tvec2,3);
n = size(tvec2,2);
d = size(tvec2,1);

tvec_rot = zeros(d,n,N);
for ii = 1:N
    t = rand(1,1)*2*pi;
    tvec_rot(:,:,ii) = [cos(t) sin(t);-sin(t) cos(t)]*tvec2(:,:,ii); % tvec is d*n*N
end

end