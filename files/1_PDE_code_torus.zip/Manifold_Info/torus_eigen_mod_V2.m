function [EigValue_torus,EigFunc_torus,THETA,PHI] = torus_eigen_mod_V2(a,Nphi,Ntheta0,Nrefine, nvtheta,nvphi,nvars)

%%% Input
    %%% a        - a > 1 radius of larger circle
    %%% Nphi     - # points of phi on [0,2pi]
    %%% Ntheta0  - # points of theta on [0,2pi)
    %%% Nrefine  - # points of refinement of theta for finite difference

    %%% nvtheta  - # eigenfunctions of theta
    %%% nvphi    - # eigenfunctions of phi
    %%% nvars    - # eigenfunctions of the torus

%%% Output
    %%% EigValue_torus - torus eigenvalue
    %%% EigFunc_torus  - torus eigenfunction
    %%% THETA          - column domain THETA
    %%% PHI            - column domain PHI 

%%% phi = [0,pi) or [0,2*pi)
%%% theta = [0,2*pi)

%% eigenfunction of Phi for phi in [0,pi) or [0,2*pi)
phi = (0:1/Nphi:1-1/Nphi)'*2*pi;

% nvphi must be odd number
if mod(nvphi,2) == 0
    nvphi = nvphi + 1;
end

% Phi eigenfunc
PhiFun = zeros(Nphi,nvphi);
PhiFun(:,1) = ones(Nphi,1);
% Phi eigenvalue
PhiMk = zeros(nvphi,1);
PhiMk(1) = 0;

for ii = 1:(nvphi-1)/2
     PhiFun(:,2*ii) = cos(ii*phi);
     PhiFun(:,2*ii+1) = sin(ii*phi);
     PhiMk(2*ii) = - ii^2;
     PhiMk(2*ii+1) = - ii^2;
end

%% SL problem is d/dtheta (p*dT/dtheta) + q*T = lambda*T*w
%% p_{+1/2}/h^2 *u_i+1 - (p_{+1/2}+p_{-1/2})/h^2 *u_i + p_{-1/2}/h^2*u_i-1 + q_i*u_i = lambda*w_i*u_i
%% eigenfunction of Theta for theta in [0,2*pi)
%%% for each nn, there are nvars eigenfunction of theta
Ntheta = Ntheta0*Nrefine;
dtheta = 2*pi/(Ntheta);
theta = (0:1/Ntheta:1-1/Ntheta)'*2*pi; % theta = [0:dtheta:2*pi-dtheta]';
theplus = theta + dtheta/2;
themins = theta - dtheta/2;
p_plus = a + cos(theplus);
p_mins = a + cos(themins);
w_i = a + cos(theta);
% D_plus = diag(w_i.^0.5);
D_mins = diag(w_i.^(-0.5));

ThtFun = zeros(Ntheta,nvtheta,nvphi); % eigenfunction of theta 
ThtVal = zeros(nvtheta,nvphi); % eigenvalue of theta

for ii = 1:nvphi
    a1 = zeros(3*Ntheta,1);
    a2 = zeros(3*Ntheta,1);
    j3 = zeros(3*Ntheta,1);
    
    % position i
    a1(1:Ntheta) = 1:Ntheta;
    a2(1:Ntheta) = 1:Ntheta;
    j3(1:Ntheta) = PhiMk(ii)./(a+cos(theta)) - (p_plus + p_mins)./dtheta^2 ;

    
    % position i+1
    a1((1:Ntheta)+Ntheta) = 1:Ntheta;
    a2((1:Ntheta)+Ntheta) = [2:Ntheta 1];
    j3((1:Ntheta)+Ntheta) = + p_plus./dtheta^2 ;

    
    % position i-1
    a1((1:Ntheta)+2*Ntheta) = 1:Ntheta;
    a2((1:Ntheta)+2*Ntheta) = [Ntheta 1:Ntheta-1];
    j3((1:Ntheta)+2*Ntheta) = + p_mins./dtheta^2 ;
            
    % eigs
    W = sparse(a1,a2,j3);
    W = (W+W')/2; 
    W = D_mins*W*D_mins;
    W = (W+W')/2; % symmetric W
    
    
    % eigs
    [psi,lambda] = eigs(W,nvtheta,0);
    lambda = diag(lambda);
    [~,perm] = sort(lambda,'descend');
    lambda = lambda(perm);
    psi = psi(:,perm);
    % L*u = lambda*W*u  <==>  W^-1*L*u = lambda*u
    % W^{-1/2}*L*W^{-1/2} * W^{+1/2}*u = lambda * W^{+1/2}*u
    psi = D_mins*psi;
    
    
    % for each PhiMk(ii), given eigs 
    ThtVal(:,ii) = lambda;
    ThtFun(:,:,ii) = psi;
    
    
end




%% Sort to find 2D eigenvalue and eigenvector, psi_new
EigValue = ThtVal; 
[EigValueSort,EigValueLoci] = sort(reshape(EigValue,nvphi*nvtheta,1),'descend');
EigValue_torus = EigValueSort(1:nvars);

%save Eigen_analytic Eigen_torus
%%% find 2D eigenvector, only the first ten eigenfunction

psi_new = zeros(Nphi*Ntheta0,nvars);

for kk = 1:nvars
    
    nthe_i = mod(EigValueLoci(kk),nvtheta);
    if nthe_i == 0 % hope nthe_i < nvtheta
        disp('larger nvtheta!');
        return;
    end
    
    nphi_i = floor((EigValueLoci(kk)-1)/nvtheta)+1;
    if nphi_i == nvphi % hope nphi_i < nvphi 
        disp('larger nvphi!');
        return;
    end
    
    eig_phi = PhiFun(:,nphi_i);
    eig_the = ThtFun(1:Nrefine:end,nthe_i,nphi_i);
    
    [EIG_THET,EIG_PHI] = meshgrid(eig_the,eig_phi);
    EIG_THET = reshape(EIG_THET,Nphi*Ntheta0,1);
    EIG_PHI = reshape(EIG_PHI,Nphi*Ntheta0,1);
    
    psi_new(:,kk) = EIG_THET.*EIG_PHI;
end
EigFunc_torus = psi_new;

%% domain output

theta0 = (0:1/Ntheta0:1-1/Ntheta0)'*2*pi;
[THETA,PHI] = meshgrid(theta0,phi);
THETA = reshape(THETA,Nphi*Ntheta0,1);
PHI = reshape(PHI,Nphi*Ntheta0,1);
    


end