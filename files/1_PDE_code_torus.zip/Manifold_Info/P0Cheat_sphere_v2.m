function [P0,tvec2] = P0Cheat_sphere_v2(theta,x,am)

N = size(x,1);
n = size(x,2);
d = size(theta,2);

%%% intrinsic data
% theta = [THETA, PHI];
%%% extrinsic data
% x = [am.*sin(THETA).*cos(PHI), am.*sin(THETA).*sin(PHI), am.*cos(THETA)];
THETA = theta(:,1);
PHI = theta(:,2);

%%% tangent direction
tvec = zeros(d,n,N);
% tangent 1
tvec(1,1,:) = am.*cos(THETA).*cos(PHI);
tvec(1,2,:) = am.*cos(THETA).*sin(PHI);
tvec(1,3,:) = - am.*sin(THETA);
% tangent 2
tvec(2,1,:) = - am.*sin(THETA).*sin(PHI);
tvec(2,2,:) = am.*sin(THETA).*cos(PHI);
tvec(2,3,:) = cos(THETA)*0;

%%% normalized tangent direction
tvec2 = zeros(d,n,N);
% normalized tangent 1
tvec2(1,:,:) = tvec(1,:,:);
% tangent 2 permute(tvec2,[3,2,1]);
tvec2_len = sqrt(squeeze(tvec(2,1,:).^2+tvec(2,2,:).^2+tvec(2,3,:).^2));
tvec2(2,1,:) = permute(permute(tvec(2,1,:),[3,2,1])./tvec2_len,[3,2,1]);
tvec2(2,2,:) = permute(permute(tvec(2,2,:),[3,2,1])./tvec2_len,[3,2,1]);
tvec2(2,3,:) = permute(permute(tvec(2,3,:),[3,2,1])./tvec2_len,[3,2,1]);

%%% analytic true projection matrix 
P0 = zeros(n,n,N);
for ii = 1:N
    P0(:,:,ii) = tvec(:,:,ii)'*pinv(tvec(:,:,ii)*tvec(:,:,ii)')*tvec(:,:,ii);
end
P0 = permute(P0,[3,2,1]); % P0 is N*n*n

end