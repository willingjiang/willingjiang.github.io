function [x,theta] = sphere_generate_v2_uniform(DATA_INDEX,am,Ntheta,Nphi)

% number of pts
N = Ntheta*Nphi;

%%% intrinsic data
%%% 1 == well-sampled data
%%% 2 == random data
if DATA_INDEX == 1 % well-sampled

    theta2 = [0:1/Ntheta:1-1/Ntheta]'+1/Ntheta/2; % maybe [0,pi]
    theta2 = acos(1-2*theta2);
    phi2 = [0:2*pi/Nphi:2*pi-2*pi/Nphi]'; % always [0 2*pi]
    
    [THETA,PHI] = meshgrid(theta2,phi2);
    THETA = reshape(THETA,N,1);
    PHI = reshape(PHI,N,1);
    
elseif DATA_INDEX == 2 % random

    THETA = rand(N,1); % maybe [0,pi]
    THETA = acos(1-2*THETA);
    PHI = rand(N,1)*2*pi; % always [0 2*pi]
    
end

%%% intrinsic data
theta = [THETA, PHI];
%%% extrinsic data
x = [am.*sin(THETA).*cos(PHI), am.*sin(THETA).*sin(PHI), am.*cos(THETA)];

 

end


