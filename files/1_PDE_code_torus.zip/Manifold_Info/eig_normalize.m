function [EigFunc_torus] = eig_normalize(EigFunc_torus,am,THETA,PHI,k)

%%% intrinsic data
% theta = [THETA, PHI];
%%% extrinsic data
x2 = [(am+cos(THETA)).*cos(PHI), (am+cos(THETA)).*sin(PHI), sin(THETA)];

%%% sampling density
[qest,~,~] = qestfind(x2,k);

nvars = size(EigFunc_torus,2);

for ii = 1:nvars
    EigFunc_torus(:,ii) = EigFunc_torus(:,ii) / sqrt(mean(EigFunc_torus(:,ii).^2./qest));
end

end