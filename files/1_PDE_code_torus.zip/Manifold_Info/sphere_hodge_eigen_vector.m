function [EigValue_sphere,EigFunc_sphere] = sphere_hodge_eigen_vector(x2)

%%% Input
    %%% a        - a > 1 radius of larger circle
    %%% Nphi     - # points of phi on [0,2pi]
    %%% Ntheta0  - # points of theta on [0,2pi)
    %%% Nrefine  - # points of refinement of theta for finite difference

    %%% nvtheta  - # eigenfunctions of theta
    %%% nvphi    - # eigenfunctions of phi
    %%% nvars    - # eigenfunctions of the torus

%%% Output
    %%% EigValue_torus - torus eigenvalue
    %%% EigFunc_torus  - torus eigenfunction
    %%% THETA          - column domain THETA
    %%% PHI            - column domain PHI 

%%% phi = [0,pi) or [0,2*pi)
%%% theta = [0,2*pi)

nvars = 16;
N = size(x2,1);
n = size(x2,2);

x = x2(:,1);
y = x2(:,2);
z = x2(:,3);
%% spherical harmonic eigenfunction
EigFunc_sphere = zeros(N*n,nvars);
EigValue_sphere = zeros(nvars,1);

EigValue_sphere(1:6,1) = -2*ones(6,1);
EigValue_sphere(7:16,1) = -6*ones(10,1);


EigFunc_sphere(0*N+(1:N),1) = x.*z;
EigFunc_sphere(1*N+(1:N),1) = y.*z;
EigFunc_sphere(2*N+(1:N),1) = -x.^2-y.^2;

EigFunc_sphere(0*N+(1:N),2) = x.*y;
EigFunc_sphere(1*N+(1:N),2) = -x.^2-z.^2;
EigFunc_sphere(2*N+(1:N),2) = y.*z;

EigFunc_sphere(0*N+(1:N),3) = -y.^2-z.^2;
EigFunc_sphere(1*N+(1:N),3) = x.*y;
EigFunc_sphere(2*N+(1:N),3) = x.*z;

EigFunc_sphere(0*N+(1:N),4) = y;
EigFunc_sphere(1*N+(1:N),4) = -x;
EigFunc_sphere(2*N+(1:N),4) = 0;

EigFunc_sphere(0*N+(1:N),5) = -z;
EigFunc_sphere(1*N+(1:N),5) = 0;
EigFunc_sphere(2*N+(1:N),5) = x;

EigFunc_sphere(0*N+(1:N),6) = 0;
EigFunc_sphere(1*N+(1:N),6) = z;
EigFunc_sphere(2*N+(1:N),6) = -y;


%%% 2nd mode
EigFunc_sphere(0*N+(1:N),7) = y-2*x.^2.*y;
EigFunc_sphere(1*N+(1:N),7) = x-2*x.*y.^2;
EigFunc_sphere(2*N+(1:N),7) = -2*x.*y.*z;

EigFunc_sphere(0*N+(1:N),8) = z-2*x.^2.*z;
EigFunc_sphere(1*N+(1:N),8) = -2*x.*y.*z;
EigFunc_sphere(2*N+(1:N),8) = x-2*x.*z.^2;

EigFunc_sphere(0*N+(1:N),9) = -2*x.*y.*z;
EigFunc_sphere(1*N+(1:N),9) = z-2*y.^2.*z;
EigFunc_sphere(2*N+(1:N),9) = y-2*y.*z.^2;

EigFunc_sphere(0*N+(1:N),10) = x-x.^3;
EigFunc_sphere(1*N+(1:N),10) = -x.^2.*y;
EigFunc_sphere(2*N+(1:N),10) = -x.^2.*z;

EigFunc_sphere(0*N+(1:N),11) = -x.*y.^2;
EigFunc_sphere(1*N+(1:N),11) = y-y.^3;
EigFunc_sphere(2*N+(1:N),11) = -y.^2.*z;

%%% 2nd mode 
EigFunc_sphere(0*N+(1:N),12) = -x.*z;
EigFunc_sphere(1*N+(1:N),12) = y.*z;
EigFunc_sphere(2*N+(1:N),12) = x.^2-y.^2;

EigFunc_sphere(0*N+(1:N),13) = -z.^2+y.^2;
EigFunc_sphere(1*N+(1:N),13) = -x.*y;
EigFunc_sphere(2*N+(1:N),13) = x.*z;

EigFunc_sphere(0*N+(1:N),14) = x.*y;
EigFunc_sphere(1*N+(1:N),14) = z.^2-x.^2;
EigFunc_sphere(2*N+(1:N),14) = -y.*z;

EigFunc_sphere(0*N+(1:N),15) = 0;
EigFunc_sphere(1*N+(1:N),15) = x.*z;
EigFunc_sphere(2*N+(1:N),15) = -x.*y;

EigFunc_sphere(0*N+(1:N),16) = -y.*z;
EigFunc_sphere(1*N+(1:N),16) = 0;
EigFunc_sphere(2*N+(1:N),16) = x.*y;


end






