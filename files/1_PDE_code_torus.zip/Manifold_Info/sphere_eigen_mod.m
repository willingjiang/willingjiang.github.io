function [EigValue_sphere,EigFunc_sphere,THETA,PHI] = sphere_eigen_mod(Nphi,Ntheta,nvars)

%%% Input
    %%% a        - a > 1 radius of larger circle
    %%% Nphi     - # points of phi on [0,2pi]
    %%% Ntheta0  - # points of theta on [0,2pi)
    %%% Nrefine  - # points of refinement of theta for finite difference

    %%% nvtheta  - # eigenfunctions of theta
    %%% nvphi    - # eigenfunctions of phi
    %%% nvars    - # eigenfunctions of the torus

%%% Output
    %%% EigValue_torus - torus eigenvalue
    %%% EigFunc_torus  - torus eigenfunction
    %%% THETA          - column domain THETA
    %%% PHI            - column domain PHI 

%%% phi = [0,pi) or [0,2*pi)
%%% theta = [0,2*pi)

ell = floor(sqrt(nvars));
nvars = (ell+1)^2;
%% eigenfunction of Theta for theta in [0,pi] 
phi = (0:1/Nphi:1-1/Nphi)'*2*pi; % [0,2*pi]
theta = [0:pi/Ntheta:pi-pi/Ntheta]'+pi/Ntheta/2; % maybe [0,pi]

[THETA,PHI] = meshgrid(theta,phi);
THETA = reshape(THETA,Nphi*Ntheta,1);
PHI = reshape(PHI,Nphi*Ntheta,1);

% associated Legendre polynomials
asL = zeros(Nphi*Ntheta,ell+1,ell+1);
for ll = 0:ell
    if ll == 0
        asL(:,ll+1,1) = zeros(Nphi*Ntheta,1)+1;
    elseif ll == 1
        asL(:,ll+1,1) = cos(THETA);
        asL(:,ll+1,2) = - sin(THETA);
    elseif ll == 2
        asL(:,ll+1,1) = 1/2.*(3*cos(THETA).^2-1);
        asL(:,ll+1,2) = -3.*cos(THETA).*sin(THETA);
        asL(:,ll+1,3) = 3.*sin(THETA).^2;
    else
        mm = 0;
        asL(:,ll+1,mm+1) = ((2*ll-1).*cos(THETA).*asL(:,ll,mm+1) - (ll-1+mm).*asL(:,ll-1,mm+1))./(ll-mm); % m = 0
        mm = 1;
        asL(:,ll+1,mm+1) = ((2*ll-1).*cos(THETA).*asL(:,ll,mm+1) - (ll-1+mm).*asL(:,ll-1,mm+1))./(ll-mm); % m = 1
        for mm = 2:ll-2
            asL(:,ll+1,mm+1) = sin(THETA).*(-1/2/mm).*( asL(:,ll,mm+2) + (ll+mm-1).*(ll+mm).*asL(:,ll,mm) );
        end
        mm = ll-1;
        asL(:,ll+1,mm+1) = (2*ll-1).*cos(THETA).*asL(:,ll,ll); % mm = ll-1
        mm = ll;
        asL(:,ll+1,mm+1) = -(2*ll-1).*sin(THETA).*asL(:,ll,mm); % mm = ll
    end
end

%% spherical harmonic eigenfunction
EigFunc_sphere = zeros(Nphi*Ntheta,nvars);
EigValue_sphere = zeros(nvars,1);

for ll = 0:ell
    for mm = -ll:-1
        EigValue_sphere(ll^2+mm+ll+1,1) = -ll*(ll+1);
        K = sqrt((2*ll+1)/4/pi * factorial(ll-abs(mm))/factorial(ll+abs(mm)) );
        EigFunc_sphere(:,ll^2+mm+ll+1) = sqrt(2)*K*sin(abs(mm).*PHI).*asL(:,ll+1,abs(mm)+1);
    end
    mm = 0;
    EigValue_sphere(ll^2+mm+ll+1,1) = -ll*(ll+1);
    K = sqrt((2*ll+1)/4/pi * factorial(ll-abs(mm))/factorial(ll+abs(mm)) );
    EigFunc_sphere(:,ll^2+mm+ll+1) = K.*asL(:,ll+1,abs(mm)+1);
    for mm = 1:ll
        EigValue_sphere(ll^2+mm+ll+1,1) = -ll*(ll+1);
        K = sqrt((2*ll+1)/4/pi * factorial(ll-abs(mm))/factorial(ll+abs(mm)) );
        EigFunc_sphere(:,ll^2+mm+ll+1) = sqrt(2)*K*cos(abs(mm).*PHI).*asL(:,ll+1,abs(mm)+1);
    end    
end

end

% % associated Legendre polynomials
% asL = zeros(Ntheta,ell+1,ell+1);
% for ll = 0:ell
%     if ll == 0
%         asL(:,ll+1,1) = Ntheta*0+1;
%     elseif ll == 1
%         asL(:,ll+1,1) = cos(theta);
%         asL(:,ll+1,2) = - sin(theta);
%     elseif ll == 2
%         asL(:,ll+1,1) = 1/2.*(3*cos(theta).^2-1);
%         asL(:,ll+1,2) = -3.*cos(theta).*sin(theta);
%         asL(:,ll+1,3) = 3.*sin(theta).^2;
%     else
%         mm = 0;
%         asL(:,ll+1,mm+1) = ((2*ll-1).*cos(theta).*asL(:,ll,mm+1) - (ll-1+mm).*asL(:,ll-1,mm+1))./(ll-mm); % m = 0
%         mm = 1;
%         asL(:,ll+1,mm+1) = ((2*ll-1).*cos(theta).*asL(:,ll,mm+1) - (ll-1+mm).*asL(:,ll-1,mm+1))./(ll-mm); % m = 1
%         for mm = 2:ll-2
%             asL(:,ll+1,mm+1) = sin(theta).*(-1/2/mm).*( asL(:,ll,mm+2) + (ll+mm-1).*(ll+mm).*asL(:,ll,mm) );
%         end
%         mm = ll-1;
%         asL(:,ll+1,mm+1) = (2*ll-1).*cos(theta).*asL(:,ll,ll); % mm = ll-1
%         mm = ll;
%         asL(:,ll+1,mm+1) = -(2*ll-1).*sin(theta).*asL(:,ll,mm); % mm = ll
%     end
% end