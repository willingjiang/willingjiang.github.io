clear all,

%% parameters for input data on manifold

addpath ./Manifold_Info

%%% intrinsic data
%%% 1 == well-sampled data
%%% 2 == random data
DATA_INDEX = 2;

%%% manifold type
%%% 1 == ellipse
%%% 2 == torus
%%% 3 == sphere
MANI_INDEX = 2;

if MANI_INDEX == 2
    %%% manifold parameter
    d = 2;
    n = 3;
    Ntheta = 32;
    Nphi = 32;
    N = Ntheta*Nphi;
    % extrinsic data
    am = 2; % a > 1 radius of larger circle
    %%% 1=LB, 2=Boch, 3=Hodge, 4=Lich
    operator = 2;
    
    %%% generate data
    rng(2);
    [x,theta] = torus_generate(DATA_INDEX,am,Ntheta,Nphi);
    %%% here should be changed to uniform sampling
    % [x,theta] = torus_generate_v2_uniform(DATA_INDEX,am,Ntheta,Nphi);
    %%% projection matrix P0
    [P0,tvec2] = torus_P0Cheat_v2(theta,x,am);
end

ManifoldParam.d = d;
ManifoldParam.n = n;
ManifoldParam.N = N;

ManifoldParam.x = x;
ManifoldParam.theta = theta;
ManifoldParam.P0 = P0;
ManifoldParam.tvec2 = tvec2;

%% parameters for projection matrix P
%%% 1 == true P0
%%% 2 == rough kernel P0_tilde
%%% 3 == P0_low
ProjMat_INDEX = 1;


%%% parameters for tangent to surface
RoughKernel.kk = 20; % 16 for ellipse and 50 for torus
RoughKernel.indxB = 1:N;

%%% parameters for low pass filtering 
%%% eigenvalue solver    
%%% fixed bandwidth only 
%%% operator == 3 is Laplace-Beltrami, operator == 4 is Kolmogorov backward 
% LowPassFilter.nvarsDM = 100;    
LowPassFilter.k = 51;
LowPassFilter.operator = 3;
LowPassFilter.DinvThr = 2e-2;
% LowPassFilter.nlow = 40; %%% number of low modes used 
% epsilon = 0.004;
% dim = 1;
%% parameters for eigenvalue problem of RBF problem

%%% given basis function
RBFEigenValue.s = 1.0;

%%% threashold for singular values to determine the dimension of null space
%%% in Gi for RBF interpolant
RBFEigenValue.SvalThr = 10.^-8;

%%% kerflag 
%%% 1 == Gauss
%%% 2 == inverse quadratic 1/(1+s^2*r^2)
RBFEigenValue.kerflag = 1;

%%% # of eigenvalues to compute
RBFEigenValue.nvars = N;
%%% threashold for eigenvalue in Bochner matrix
%%% take EigvalThr as small as possible to kill the zero eigenvalue 
%%% (which is smaller than EigvalThr) and
%%% corresponding eigenvector since finally we will add 0 eigenvalue and 1
%%% eigenvector manually. 
RBFEigenValue.EigvalThr = 4e-1;

%% setup for PDE, torus analytic computation

% manifold
% x = [(am+cos(THETA)).*cos(PHI), (am+cos(THETA)).*sin(PHI), sin(THETA)];
syms theta2 phi2 %intrinsic coordinate
x_1 = (am+cos(theta2))*cos(phi2);
x_2 = (am+cos(theta2))*sin(phi2);
x_3 = sin(theta2);

t1_1 = diff(x_1,theta2);
t1_2 = diff(x_2,theta2);
t1_3 = diff(x_3,theta2);

t2_1 = diff(x_1,phi2);
t2_2 = diff(x_2,phi2);
t2_3 = diff(x_3,phi2);

%%% Riemannian metric
g(1,1)=t1_1^2+t1_2^2+t1_3^2;
g(1,2)=t1_1*t2_1+t1_2*t2_2+t1_3*t2_3;
g(2,1)=g(1,2);
g(2,2)=t2_1^2+t2_2^2+t2_3^2;
%%% forcing term of burger's equation
% trivial is u1=0,u2=1.
% nontrivial is u1=1,u2=0.
u1 = sin(theta2)*sin(phi2); % symbolic, u1 = sin(theta2);
u2 = sin(theta2)*sin(phi2);
% % corresponding vector for numerics
% u1_vec = 1; % numerics, u1_vec = sin(theta(:,1));
% u2_vec = 0;
% u1 = 1; u2 = 0;
% f1 = - (((2*cos(phi2)^2*sin(theta2)*(cos(theta2) + 2) + 2*sin(phi2)^2*sin(theta2)*(cos(theta2) + 2))*(2*cos(phi2)^2*cos(theta2)*sin(theta2) - 2*cos(theta2)*sin(theta2) + 2*cos(theta2)*sin(phi2)^2*sin(theta2)))/(4*(cos(phi2)^2*sin(theta2)^2 + cos(theta2)^2 + sin(phi2)^2*sin(theta2)^2)^2) + (2*cos(phi2)^2*sin(theta2)*(cos(theta2) + 2) + 2*sin(phi2)^2*sin(theta2)*(cos(theta2) + 2))^2/(4*(cos(phi2)^2*sin(theta2)^2 + cos(theta2)^2 + sin(phi2)^2*sin(theta2)^2)*(4*cos(phi2)^2 + 4*sin(phi2)^2 + 4*cos(phi2)^2*cos(theta2) + 4*cos(theta2)*sin(phi2)^2 + cos(phi2)^2*cos(theta2)^2 + cos(theta2)^2*sin(phi2)^2)))/(4*cos(phi2)^2 + 4*sin(phi2)^2 + 4*cos(phi2)^2*cos(theta2) + 4*cos(theta2)*sin(phi2)^2 + cos(phi2)^2*cos(theta2)^2 + cos(theta2)^2*sin(phi2)^2) - ((2*cos(theta2)^2 - 2*sin(theta2)^2 - 2*cos(phi2)^2*cos(theta2)^2 + 2*cos(phi2)^2*sin(theta2)^2 - 2*cos(theta2)^2*sin(phi2)^2 + 2*sin(phi2)^2*sin(theta2)^2)/(2*(cos(phi2)^2*sin(theta2)^2 + cos(theta2)^2 + sin(phi2)^2*sin(theta2)^2)) + (2*cos(phi2)^2*cos(theta2)*sin(theta2) - 2*cos(theta2)*sin(theta2) + 2*cos(theta2)*sin(phi2)^2*sin(theta2))^2/(2*(cos(phi2)^2*sin(theta2)^2 + cos(theta2)^2 + sin(phi2)^2*sin(theta2)^2)^2))/(cos(phi2)^2*sin(theta2)^2 + cos(theta2)^2 + sin(phi2)^2*sin(theta2)^2);
% f2 = 0; 
% [f1,f2]=Boch_2d(theta2,phi2,g,u1,u2);
[f1,f2]=Vec_2d(theta2,phi2,g,u1,u2,operator);

F2_1 = matlabFunction(f1); % @(phi,theta) or @()0.0
F2_2 = matlabFunction(f2); % @(phi,theta) or @()0.0

% corresponding vector for numerics
u1_vec = sin(theta(:,1)).*sin(theta(:,2)); % numerics, u1_vec = sin(theta(:,1));
u2_vec = sin(theta(:,1)).*sin(theta(:,2));
%%% syms to matlab data
[u_true_col,upp_true_col,U_true_col,Upp_true_col] = torus_syms_to_matlab_data_v2(theta,tvec2,F2_1,F2_2,am,u1_vec,u2_vec);

%%% solve (I-Delta)*u = f
rhs = u_true_col - upp_true_col;

%% Main
tic
[Matrix_Boch] = Main_BochnerMatrix_V2_intd(ManifoldParam,RoughKernel,LowPassFilter,ProjMat_INDEX,RBFEigenValue);
a1 = toc;

%%% GFDM numerical Lich Laplacian
bochU_col_num1 = Matrix_Boch*u_true_col;
tic
sol1 = (speye(d*N)-Matrix_Boch)\rhs;
a2 = toc;

%%% from d to n
BochU_col_num1 = zeros(N*n,1);
for ii = 1:n
    for jj = 1:d
        BochU_col_num1((1:N)+(ii-1)*N,1) = BochU_col_num1((1:N)+(ii-1)*N,1) + bochU_col_num1((1:N)+(jj-1)*N,1).*squeeze(tvec2(jj,ii,:));
    end
end
Sol1 = zeros(N*n,1);
for ii = 1:n
    for jj = 1:d
        Sol1((1:N)+(ii-1)*N,1) = Sol1((1:N)+(ii-1)*N,1) + sol1((1:N)+(jj-1)*N,1).*squeeze(tvec2(jj,ii,:));
    end
end

%%% compute FE and IE
disp('consistency');
err_FE1 = reshape(BochU_col_num1-Upp_true_col,N,n);
errP_local_Linf1 = max(sqrt(sum(err_FE1.^2,2)));
FE = errP_local_Linf1;
[errP_local_Linf1]

disp('convergence');
err_sol1 = reshape(Sol1-U_true_col,N,n);
err_sol_Linf1 = max(sqrt(sum(err_sol1.^2,2)));
IE = err_sol_Linf1;
[err_sol_Linf1]

atime = a1+a2;

%% save data
save(['globalrbf_torus_boch_' num2str(N)],'FE','IE','atime');

return




%% ����




