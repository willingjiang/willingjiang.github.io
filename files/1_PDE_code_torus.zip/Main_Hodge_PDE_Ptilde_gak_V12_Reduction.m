clear all,

%% parameters for input data on manifold

addpath ./Manifold_Info
addpath ./Estimate_Filter_P
addpath ./RBF_Matrix

%%% intrinsic data
%%% 1 == well-sampled data
%%% 2 == random data
DATA_INDEX = 2;

%%% manifold type
%%% 1 == ellipse
%%% 2 == torus
%%% 3 == sphere
MANI_INDEX = 3;

if MANI_INDEX == 3
    %%% manifold parameter
    d = 2;
    n = 3;
    Ntheta = 32;
    Nphi = 32;
    N = Ntheta*Nphi;
    % extrinsic data
    am = 1; % radius fixed to be 1
    
    %%% generate data
    rng(2);
    % [x,theta] = sphere_generate(DATA_INDEX,am,Ntheta,Nphi); 
    %%% here should be changed to uniform sampling
    [x,theta] = sphere_generate_v2_uniform(DATA_INDEX,am,Ntheta,Nphi);
    %%% projection matrix P0
    % [P0,tvec2] = P0Cheat_sphere_v2(theta,x,am);
    
    %%% index for tangent space
    indxB = 1:N;
    %%% gmls approx. of tangent space
    degr = 5;
    %%% k-NN
    k0 = 31;
    %%% approximated tangent spaces
    [P0,tvec2] = gmls_localPCA_v2(x,k0,d,n,degr,indxB); % [P0_tilde,tvec_tilde] = gmls_localPCA_v2(x,k0,d,n,degr,indxB);
end

ManifoldParam.d = d;
ManifoldParam.n = n;
ManifoldParam.N = N;

ManifoldParam.x = x;
ManifoldParam.theta = theta;
ManifoldParam.P0 = P0;
ManifoldParam.tvec2 = tvec2;

%% Analytic Eigs
if MANI_INDEX == 3 % 3 == sphere
    [EigValue_torus,EigFunc_torus] = sphere_hodge_eigen_vector(x);
end

%% parameters for projection matrix P
%%% 1 == true P0
%%% 2 == rough kernel P0_tilde
%%% 3 == P0_low
ProjMat_INDEX = 1;


%%% parameters for tangent to surface
RoughKernel.kk = 20; % 16 for ellipse and 50 for torus
RoughKernel.indxB = 1:N;

%%% parameters for low pass filtering 
%%% eigenvalue solver    
%%% fixed bandwidth only 
%%% operator == 3 is Laplace-Beltrami, operator == 4 is Kolmogorov backward 
% LowPassFilter.nvarsDM = 100;    
LowPassFilter.k = 51;
LowPassFilter.operator = 3;
LowPassFilter.DinvThr = 2e-2;
% LowPassFilter.nlow = 40; %%% number of low modes used 
% epsilon = 0.004;
% dim = 1;
%% parameters for eigenvalue problem of RBF problem

%%% given basis function
RBFEigenValue.s = 0.5;

%%% threashold for singular values to determine the dimension of null space
%%% in Gi for RBF interpolant
RBFEigenValue.SvalThr = 10.^-7;

%%% kerflag 
%%% 1 == Gauss
%%% 2 == inverse quadratic 1/(1+s^2*r^2)
RBFEigenValue.kerflag = 1;

%%% # of eigenvalues to compute
RBFEigenValue.nvars = N;
%%% threashold for eigenvalue in Bochner matrix
%%% take EigvalThr as small as possible to kill the zero eigenvalue 
%%% (which is smaller than EigvalThr) and
%%% corresponding eigenvector since finally we will add 0 eigenvalue and 1
%%% eigenvector manually. 
RBFEigenValue.EigvalThr = 4e-1;

%% setup for the PDE 
%%% solve (I-Delta)*u = f
jj = 1;
U_true_col = EigFunc_torus(:,jj);
Upp_true_col = EigValue_torus(jj)*EigFunc_torus(:,jj);

%%% intrinsic representation (projection) of true solution 
u_true_col = zeros(N*d,1);
for ii = 1:d
    for jj = 1:n
        u_true_col((1:N)+(ii-1)*N,1) = u_true_col((1:N)+(ii-1)*N,1) + U_true_col((1:N)+(jj-1)*N,1).*squeeze(tvec2(ii,jj,:));
    end
end
%%% intrinsic representation (projection) of vector Laplacian
upp_true_col = zeros(N*d,1);
for ii = 1:d
    for jj = 1:n
        upp_true_col((1:N)+(ii-1)*N,1) = upp_true_col((1:N)+(ii-1)*N,1) + Upp_true_col((1:N)+(jj-1)*N,1).*squeeze(tvec2(ii,jj,:));
    end
end

%%% solve (I-Delta)*u = f
rhs = u_true_col - upp_true_col;

%% Main
tic
[Matrix_Hodge] = Main_HodgeMatrix_V2_intd(ManifoldParam,RoughKernel,LowPassFilter,ProjMat_INDEX,RBFEigenValue);
a1 = toc;

%%% RBF numerical Hodge Laplacian
hodgU_col_num1 = Matrix_Hodge*u_true_col;
tic
sol1 = (speye(d*N)-Matrix_Hodge)\rhs;
a2 = toc;

%%% from d to n
HodgeU_col_num1 = zeros(N*n,1);
for ii = 1:n
    for jj = 1:d
        HodgeU_col_num1((1:N)+(ii-1)*N,1) = HodgeU_col_num1((1:N)+(ii-1)*N,1) + hodgU_col_num1((1:N)+(jj-1)*N,1).*squeeze(tvec2(jj,ii,:));
    end
end
Sol1 = zeros(N*n,1);
for ii = 1:n
    for jj = 1:d
        Sol1((1:N)+(ii-1)*N,1) = Sol1((1:N)+(ii-1)*N,1) + sol1((1:N)+(jj-1)*N,1).*squeeze(tvec2(jj,ii,:));
    end
end

%%% compute FE and IE
disp('consistency');
err_FE1 = reshape(HodgeU_col_num1-Upp_true_col,N,n);
errP_local_Linf1 = max(sqrt(sum(err_FE1.^2,2)));
FE = errP_local_Linf1;
[errP_local_Linf1]

disp('convergence');
err_sol1 = reshape(Sol1-U_true_col,N,n);
err_sol_Linf1 = max(sqrt(sum(err_sol1.^2,2)));
IE = err_sol_Linf1;
[err_sol_Linf1]

atime = a1+a2;

%% save data
save(['globalrbf_hodge_' num2str(N)],'FE','IE','atime');

return


%% save data

% save random_fun_P0 EigFunc_torus rbfvector_old rbfvector ind_true ind_RBF  L2_RBF N nvars
% save random_val_P0 EigValue_torus rbflambda  ind_RBF  L2_RBF N nvars rbflambda_complex x theta

% save random_fun_P0 EigFunc_torus rbfvector DMvector ind_true ind_RBF ind_DM L2_DM L2_RBF N nvars
% save random_val_P0 EigValue_torus rbflambda DMlambda  ind_RBF  L2_DM L2_RBF N nvars rbflambda_complex

%% ����




